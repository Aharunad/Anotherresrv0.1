# ATLAS Planet Finder — fresh Android project v1.0

This is a fresh Android app shell and redesigned interface, reusing the bundled APF Python engine and its data files from the supplied source ZIP. It is intended to be uploaded as the root of a new GitHub repository.

## Build an APK with GitHub Actions
1. Create a new empty GitHub repository.
2. Upload the **contents** of this folder to the repository root (not an extra nested folder).
3. Open the **Actions** tab and select **Build ATLAS Planet Finder APK**.
4. Choose **Run workflow**. If GitHub asks, enable Actions for the repository first.
5. When the run succeeds, open the run and download `ATLAS-Planet-Finder-v1.0-debug-APK` under Artifacts.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android device.

The workflow file is `.github/workflows/build-atlas-planet-finder.yml`.

## What is new
- Fresh app identity and version 1.0 (`com.atlasfuturica.finder`), separate from the prior application ID.
- Rebuilt, responsive dark sci-fi search interface.
- Portal and galaxy input, scan limits, stop target, pause/stop/extend controls.
- Terrain family choices for Mountain Ravines, Alien, Desert, Floating Islands, Grand Canyon, Huge Arches, Craters, Caverns, Alpine and Lily Pad.
- Search calls the bundled Python `any_planet_finder_core.find_planets` engine through `atlas_bridge.py` in the Android host; results and telemetry are read from the bridge.
- GitHub Actions workflow is included at the requested path.

## Important honest limitations
The supplied source package includes real engine code and data, and its previous test note records limited desktop Python smoke tests. That is not the same as verifying an Android APK. This environment has not built or installed the APK on a device. The workflow must succeed, and the installed app must be tested on-device before claiming runtime success. Some advanced filters in `atlas_bridge.py` remain unmapped; the UI only exposes a deliberately smaller set of filter fields. The terrain names are passed to the engine, but not every name has been independently validated against the core's accepted values.

## Test checklist
See `WRITTEN_TEST_PLAN.md` for the test procedure and pass/fail record. Do not mark device tests as passed until they have actually been run.
