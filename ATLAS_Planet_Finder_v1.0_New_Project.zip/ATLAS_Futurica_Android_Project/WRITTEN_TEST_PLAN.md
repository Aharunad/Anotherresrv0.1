# ATLAS Planet Finder v1.0 — written test plan

**Status: NOT YET RUN ON ANDROID DEVICE.** This document is a test plan, not a claim that the app has passed device testing.

## A. Build and installation
- [ ] GitHub Actions workflow starts from the Actions tab.
- [ ] Workflow completes successfully and uploads `ATLAS-Planet-Finder-v1.0-debug-APK`.
- [ ] APK installs on an Android device without package conflict with the old app.
- [ ] App opens and shows `ATLAS / PLANET FINDER` with build 1.0.

## B. Engine bridge
- [ ] Start a search with a valid 12-character portal address and Euclid selected.
- [ ] Status changes from Ready to an active scan state.
- [ ] Systems/planet evaluation counters update.
- [ ] When the engine returns matches, result records appear in the result area.
- [ ] A valid search with no matches reports zero results without crashing.
- [ ] Invalid or missing portal address is rejected before the scan starts.

## C. Search controls
- [ ] Stop ends the active search.
- [ ] Pause and resume change scan state and resume progress.
- [ ] Extend increases the allowed scan range when the engine supports continuation.
- [ ] Target stop setting behaves as expected.

## D. Terrain family filters
Run a small scan for each terrain family individually and record whether the engine accepts it and whether records are returned:
- [ ] Mountain Ravines
- [ ] Alien
- [ ] Desert
- [ ] Floating Islands (terrain)
- [ ] Grand Canyon
- [ ] Huge Arches
- [ ] Craters
- [ ] Caverns
- [ ] Alpine
- [ ] Lily Pad

Also test two terrain families selected together and check that returned records are merged without duplicate records.

## E. Record results
For every test above, record device model, Android version, date, pass/fail, and any error text. A no-match result is not automatically a failure; a crash, unhandled engine exception, or filter value that the core rejects is a failure requiring investigation.

## Current evidence available before device testing
The supplied v0.2 checkpoint report describes limited Python core smoke tests and JavaScript syntax checks. It explicitly says Android APK compilation/install/runtime and full filter coverage were not verified. Those earlier results do not prove that this fresh v1.0 Android package works on-device.
