#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899
AVALANCHE_MULTIPLIER_1 = 0x64DD81482CBD31D7
AVALANCHE_MULTIPLIER_2 = 0xE36AA5C613612997


def rotate_right_32(value: int, count: int) -> int:
    count &= 31
    if count == 0:
        return value & MASK32
    return (
        ((value >> count) | (value << (32 - count)))
        & MASK32
    )


def avalanche_mix_64(value: int) -> int:
    value &= MASK64
    value ^= value >> 33
    value = (
        value * AVALANCHE_MULTIPLIER_1
    ) & MASK64
    value ^= value >> 33
    value = (
        value * AVALANCHE_MULTIPLIER_2
    ) & MASK64
    value ^= value >> 33
    return value & MASK64


class MWCState:
    def __init__(self, low: int, high: int):
        self.low = low & MASK32
        self.high = high & MASK32
        self.draw_count = 0

    @classmethod
    def from_seed(cls, seed: int) -> "MWCState":
        low = seed & MASK32
        if low == 0:
            low = 1
        high_word = (seed >> 32) & MASK32
        carry = (
            rotate_right_32(low, 16)
            ^ high_word
            ^ low
        ) & MASK32
        return cls(low, carry)

    def draw(self) -> int:
        total = (
            MWC_MULTIPLIER * self.low + self.high
        ) & MASK64
        self.low = total & MASK32
        self.high = (total >> 32) & MASK32
        self.draw_count += 1
        return self.low


def generate_child_seeds(root_seed: int) -> list[int]:
    state = MWCState.from_seed(root_seed)
    children = []
    for _ in range(26):
        first = state.draw()
        second = state.draw()
        combined = (
            ((second & MASK32) << 32)
            | (first & MASK32)
        )
        children.append(avalanche_mix_64(combined))
    return children


def selector_child_8_state(root_seed: int) -> tuple[MWCState, dict[str, Any]]:
    child_seed = generate_child_seeds(root_seed)[7]
    shared = MWCState.from_seed(child_seed)
    first = shared.draw()
    second = shared.draw()
    combined = (
        ((second & MASK32) << 32)
        | (first & MASK32)
    )
    mixed = avalanche_mix_64(combined)
    return MWCState.from_seed(mixed), {
        "child_seed_hex": f"0x{child_seed:016X}",
        "shared_seed_draw_1": first,
        "shared_seed_draw_2": second,
        "selector_seed_hex": f"0x{mixed:016X}",
    }


def multiply_high_index(word: int, count: int) -> int:
    if count <= 0:
        raise ValueError("Option count must be positive.")
    return ((word & MASK32) * count) >> 32


class SurfaceObjectListRule:
    def __init__(
        self,
        rule_path: Path,
        capability_path: Path,
    ):
        self.rule_data = json.loads(
            rule_path.read_text(encoding="utf-8-sig")
        )
        capability_data = json.loads(
            capability_path.read_text(
                encoding="utf-8-sig"
            )
        )
        self.capabilities = capability_data[
            "capabilities"
        ]

    def source_file(
        self,
        biome: int,
        biome_subtype: int,
    ) -> str:
        try:
            return self.rule_data[
                "source_lookup_numeric"
            ][str(int(biome))][str(int(biome_subtype))]
        except KeyError as exc:
            raise KeyError(
                "No current-build biome source for "
                f"Biome={biome}, BiomeSubType={biome_subtype}."
            ) from exc

    def predict(
        self,
        *,
        planet_seed: int,
        biome: int,
        biome_subtype: int,
        life_level: int,
    ) -> dict[str, Any]:
        source_file = self.source_file(
            biome, biome_subtype
        )
        source_rule = self.rule_data[
            "source_rules"
        ][source_file]
        state, seed_info = selector_child_8_state(
            planet_seed
        )

        row_trace = []
        main_result = None
        for row in source_rule["rows_through_main"]:
            probability_word = state.draw()
            probability = float(row["probability"])
            probability_random = (
                probability_word / 4294967296.0
            )
            accepted = (
                probability >= 1.0
                or probability_random < probability
            )

            index_word = state.draw()
            options = row["options"]
            rng_index = multiply_high_index(
                index_word, len(options)
            )
            selected_index = (
                int(life_level)
                if row["choose_using_life_level"]
                else rng_index
            )
            selected_index_valid = (
                0 <= selected_index < len(options)
            )
            selected_path = (
                options[selected_index]
                if accepted and selected_index_valid
                else ""
            )
            trace = {
                "row_index": row["row_index"],
                "name": row["name"],
                "probability_word": probability_word,
                "probability_random": probability_random,
                "probability": probability,
                "accepted": accepted,
                "index_word": index_word,
                "option_count": len(options),
                "rng_index": rng_index,
                "choose_using_life_level": row[
                    "choose_using_life_level"
                ],
                "life_level": int(life_level),
                "selected_index": selected_index,
                "selected_index_valid": selected_index_valid,
                "selected_path": selected_path,
            }
            row_trace.append(trace)
            if row["name"] == "MAIN":
                main_result = trace
                break

        if main_result is None:
            raise RuntimeError(
                f"MAIN row was not reached for {source_file}."
            )
        if not main_result["accepted"]:
            raise RuntimeError(
                f"MAIN probability rejected for {source_file}."
            )
        if not main_result["selected_index_valid"]:
            raise RuntimeError(
                "MAIN selected index is outside its source "
                f"Options array: {main_result}."
            )

        capability = self.capabilities.get(
            main_result["selected_path"],
            {},
        )
        return {
            "planet_seed_hex": (
                f"0x{planet_seed & MASK64:016X}"
            ),
            "biome": int(biome),
            "biome_subtype": int(biome_subtype),
            "life_level": int(life_level),
            "source_file": source_file,
            "selector_seed": seed_info,
            "row_trace": row_trace,
            "main": main_result,
            "capability": capability,
            "surface_capability": {
                "explicit_grass_asset_available": (
                    int(capability.get(
                        "explicit_grass_scene_count", 0
                    )) > 0
                ),
                "glowing_grass_asset_available": (
                    int(capability.get(
                        "glowing_grass_scene_count", 0
                    )) > 0
                ),
                "ground_foliage_candidate_available": (
                    int(capability.get(
                        "ground_foliage_candidate_count", 0
                    )) > 0
                ),
                "glowing_ground_foliage_available": (
                    int(capability.get(
                        "glowing_ground_foliage_count", 0
                    )) > 0
                ),
                "mushroom_asset_available": (
                    int(capability.get(
                        "mushroom_scene_count", 0
                    )) > 0
                ),
                "glowing_mushroom_asset_available": (
                    int(capability.get(
                        "glowing_mushroom_scene_count", 0
                    )) > 0
                ),
            },
            "claim": (
                "Generated primary-surface asset capability. "
                "Visible local coverage is a separate live observation."
            ),
        }
