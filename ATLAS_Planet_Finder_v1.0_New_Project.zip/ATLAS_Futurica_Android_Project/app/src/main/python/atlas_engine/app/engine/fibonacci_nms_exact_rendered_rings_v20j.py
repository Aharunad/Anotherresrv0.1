#!/usr/bin/env python3
"""Exact address-only rendered-ring selector for ATLAS APF v1.0.58.

The ordinary-system route is a direct clean-room port of the native MWC
selector at RVA 0x16C5BDB. It selects exactly one primary, non-moon body.
Purple systems do not expose rendered planetary rings in the current build.

Live validation corpus:
- 27 systems / 149 planets
- 17 non-purple systems / 93 planets
- 10 purple systems / 56 planets
- 8 systems also visually checked in-game
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
CLEANROOM = HERE / "cleanroom"
if str(CLEANROOM) not in sys.path:
    sys.path.insert(0, str(CLEANROOM))

import fibonacci_nms_address_only_predictor_v2m as v2m
import fibonacci_nms_direct_rng_budget_v2r as v2r
import fibonacci_nms_exact_biome_subtype_solver_v2q as v2q

VERSION = "20J.0.0"
TAG = "exact_rendered_rings_v20j"
DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "RING_SELECTOR_LIVE_CORPUS_V1058.json"


def predict_system_rings(portal: str, galaxy_index: int = 0) -> dict[str, Any]:
    decoded = v2m.decode_portal(portal, galaxy_index)
    system = v2m.predict_system(decoded)
    structure = v2r.replay_primary_structure(decoded, system)
    final_sizes = [int(value) for value in structure["planet_sizes"]]
    final_count = len(final_sizes)
    star_type = int(system["star_type_raw"])

    if star_type == 4:
        return {
            "version": VERSION,
            "tag": TAG,
            "system_address": decoded.resolved_system_portal,
            "star_type_raw": star_type,
            "planet_count": final_count,
            "ring_flags": [False] * final_count,
            "ringed_internal_slots": [],
            "ringed_planet_numbers": [],
            "selector_word_hex": "",
            "selector_draw_index": None,
            "candidate_internal_slots": [],
            "prediction_exact": True,
            "status": "exact_purple_system_no_rendered_rings_v20j",
        }

    budget = v2r.calculate_entry_budget(system, structure)
    if not bool(budget["supported_for_final_prediction"]):
        raise RuntimeError(
            f"Rendered-ring selector does not support StarType {star_type}."
        )

    state = v2q.initial_direct_tkseed_state(int(decoded.tkseed))
    selector_word = 0
    for _ in range(int(budget["entry_offset"])):
        selector_word = state.draw()

    primary_sizes = [int(value) for value in structure["primary_sizes"]]
    primary_parents = [
        int(value) for value in structure["primary_parent_indices"]
    ]
    candidates = [
        slot
        for slot, (size, parent) in enumerate(
            zip(primary_sizes, primary_parents)
        )
        if size != 3 and parent == -1
    ]
    if not candidates:
        raise RuntimeError("Native rendered-ring candidate list is empty.")

    selected_ordinal = (
        (int(selector_word) & 0xFFFFFFFF) * len(candidates)
    ) >> 32
    selected_slot = int(candidates[selected_ordinal])
    flags = [False] * final_count
    flags[selected_slot] = True

    return {
        "version": VERSION,
        "tag": TAG,
        "system_address": decoded.resolved_system_portal,
        "star_type_raw": star_type,
        "planet_count": final_count,
        "ring_flags": flags,
        "ringed_internal_slots": [selected_slot],
        "ringed_planet_numbers": [selected_slot + 1],
        "selector_word_hex": f"0x{selector_word:08X}",
        "selector_draw_index": int(budget["entry_offset"]) - 1,
        "selector_draw_count": int(budget["entry_offset"]),
        "candidate_internal_slots": candidates,
        "selected_candidate_ordinal": int(selected_ordinal),
        "prediction_exact": True,
        "status": "exact_native_rendered_ring_selector_v20j",
    }


def apply_to_rows(
    portal: str,
    rows: list[dict[str, Any]],
    galaxy_index: int = 0,
) -> dict[str, Any]:
    prediction = predict_system_rings(portal, galaxy_index)
    flags = list(prediction["ring_flags"])
    if len(rows) != len(flags):
        raise RuntimeError(
            "Rendered-ring prediction count does not match planet rows: "
            f"{len(flags)} != {len(rows)}"
        )
    for index, row in enumerate(rows):
        has_rings = bool(flags[index])
        row.update({
            "has_rings": has_rings,
            "rings_display": "Rings" if has_rings else "No rings",
            "rings_prediction_exact": True,
            "rings_filter_available": True,
            "rings_prediction_status": prediction["status"],
            "ring_candidate_internal_slots": list(
                prediction["candidate_internal_slots"]
            ),
            "ring_selector_word_hex": prediction["selector_word_hex"],
            "ring_selector_draw_index": prediction["selector_draw_index"],
        })
    return prediction


def run_regression() -> dict[str, Any]:
    payload = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    system_checks: dict[str, bool] = {}
    planet_checks = 0
    planet_total = 0
    manual_checks: dict[str, bool] = {}
    nonpurple = 0
    purple = 0

    for control in payload["systems"]:
        address = str(control["system_address"])
        expected = [bool(value) for value in control["runtime_ring_flags"]]
        result = predict_system_rings(address)
        actual = [bool(value) for value in result["ring_flags"]]
        exact = actual == expected
        system_checks[address] = exact
        planet_checks += sum(a == b for a, b in zip(actual, expected))
        planet_total += len(expected)
        if int(control["star_type_raw"]) == 4:
            purple += 1
        else:
            nonpurple += 1

        observation = control.get("manual_observation")
        if observation is not None:
            manual_expected = [
                int(value) for value in observation.get("planet_numbers", [])
            ]
            manual_checks[address] = (
                list(result["ringed_planet_numbers"]) == manual_expected
            )

    exact = (
        all(system_checks.values())
        and planet_checks == planet_total
        and all(manual_checks.values())
    )
    return {
        "version": VERSION,
        "tag": TAG,
        "status": (
            "PASS_EXACT_RENDERED_RING_SELECTOR_V20J"
            if exact else "FAIL_RENDERED_RING_SELECTOR_V20J"
        ),
        "exact": exact,
        "systems_exact": sum(system_checks.values()),
        "systems_total": len(system_checks),
        "planets_exact": planet_checks,
        "planets_total": planet_total,
        "manual_systems_exact": sum(manual_checks.values()),
        "manual_systems_total": len(manual_checks),
        "nonpurple_systems": nonpurple,
        "purple_systems": purple,
        "system_checks": system_checks,
        "manual_checks": manual_checks,
        "checks": {
            **{f"runtime_system_{key}": value for key, value in system_checks.items()},
            **{f"manual_system_{key}": value for key, value in manual_checks.items()},
        },
    }


if __name__ == "__main__":
    print(json.dumps(run_regression(), indent=2))
