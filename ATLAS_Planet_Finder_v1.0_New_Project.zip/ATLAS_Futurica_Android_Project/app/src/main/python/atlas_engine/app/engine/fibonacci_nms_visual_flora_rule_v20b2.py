#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def normalize_path(value: Any) -> str:
    return str(value or "").replace("\\", "/").strip().upper()


class VisualFloraRule:
    def __init__(self, rule_data_path: Path):
        self.data = json.loads(
            rule_data_path.read_text(encoding="utf-8-sig")
        )
        self.grass_scene = normalize_path(
            self.data["bioluminescent_grass_carpet_scene"]
        )
        self.large_tree_scenes = {
            normalize_path(value)
            for value in self.data[
                "large_glowing_mushroom_tree_scenes"
            ]
        }
        self.small_mushroom_scenes = {
            normalize_path(value)
            for value in self.data[
                "small_glowing_mushroom_flora_scenes"
            ]
        }

    def classify_capability(
        self,
        capability: dict[str, Any],
    ) -> dict[str, Any]:
        explicit_grass = {
            normalize_path(value)
            for value in capability.get(
                "explicit_grass_scenes", []
            )
        }
        broad_glowing_grass = {
            normalize_path(value)
            for value in capability.get(
                "glowing_grass_scenes", []
            )
        }
        broad_glowing_mushrooms = {
            normalize_path(value)
            for value in capability.get(
                "glowing_mushroom_scenes", []
            )
        }

        exact_grass_scenes = sorted(
            explicit_grass & {self.grass_scene}
        )
        large_tree_scenes = sorted(
            broad_glowing_mushrooms & self.large_tree_scenes
        )
        small_mushroom_scenes = sorted(
            broad_glowing_mushrooms & self.small_mushroom_scenes
        )

        return {
            "bioluminescent_grass_carpet_available": bool(
                exact_grass_scenes
            ),
            "bioluminescent_grass_carpet_scenes": exact_grass_scenes,
            "large_glowing_mushroom_tree_available": bool(
                large_tree_scenes
            ),
            "large_glowing_mushroom_tree_scenes": large_tree_scenes,
            "small_glowing_mushroom_flora_available": bool(
                small_mushroom_scenes
            ),
            "small_glowing_mushroom_flora_scenes": small_mushroom_scenes,
            "any_emissive_grass_asset_available": bool(
                broad_glowing_grass
            ),
            "any_emissive_grass_scenes": sorted(
                broad_glowing_grass
            ),
            "any_emissive_mushroom_asset_available": bool(
                broad_glowing_mushrooms
            ),
            "any_emissive_mushroom_scenes": sorted(
                broad_glowing_mushrooms
            ),
            "claim": (
                "Exact generated visual asset variant. Local visible "
                "coverage and the model's selected GroundColourIndex "
                "channel remain separate observations."
            ),
        }

    def verify_static(self) -> dict[str, Any]:
        checks = {
            "grass_scene_exact": (
                self.grass_scene
                == "MODELS/PLANETS/BIOMES/COMMON/GRASS/"
                "BUBBLELUSHGRASS.SCENE.MBIN"
            ),
            "large_tree_scene_count": len(
                self.large_tree_scenes
            ) == 4,
            "small_mushroom_scene_count": len(
                self.small_mushroom_scenes
            ) == 4,
            "large_small_disjoint": not bool(
                self.large_tree_scenes
                & self.small_mushroom_scenes
            ),
        }
        return {
            "exact": all(checks.values()),
            "checks": checks,
        }
