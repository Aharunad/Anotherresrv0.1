#!/usr/bin/env python3
"""
FIBONACCI NMS DIRECT RNG BUDGET SOLVER V2R

Offline clean-room port of the direct-RNG draw budget consumed by
RVA 0x16C51F0 before the biome phase at RVA 0x16C3F60 begins.

For normal StarType values 0..3, the entry offset is now calculated from
the address-derived primary PlanetSize and parent-index arrays instead of
being solved from known biome outputs.

Static schedule
---------------
1 draw  : unconditional spread/orbit seed at 0x16C526F

For every primary body whose PlanetSize is not 3:
2 draws : 0x16C5704 and 0x16C587D
1 draw  : 0x16C59DF when at least one root primary exists

For PlanetSize 3 bodies:
0 draws in the body path; one later draw is consumed for each distinct
parent bucket containing at least one size-3 body at 0x16C5ABB.

1 draw  : root-primary selector at 0x16C5BDB when root_count > 0

Secondary orbit generation starts from a copied local state at 0x16C5C64
and therefore does not advance the main biome-entry RNG state.

Current boundary
----------------
V2R calculates the address-only biome-phase entry offset and validates the
complete V2Q Biome/BiomeSubType result for the two controlled systems.

For an arbitrary address, final Biome/BiomeSubType still requires the final
Class array generated inside RVA 0x16C3F60. V2R accepts that array through
--classes for controlled validation, but does not invent it.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import fibonacci_nms_address_only_predictor_v2m as v2m
import fibonacci_nms_exact_biome_subtype_solver_v2q as v2q

VERSION = "2R.0.0"
SUPPORTED_NORMAL_STAR_TYPES = {0, 1, 2, 3}


def load_assets(base: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    tables = v2q.normalise_biome_tables(
        v2q.load_json(base / "biome_tables_v2n_compact.json")
    )
    catalogs = v2q.normalise_catalogs(
        v2q.load_json(base / "biome_special_catalog_compact_v2p.json")
    )
    vectors = v2q.load_json(base / "known_biome_vectors_v2q.json")
    return tables, catalogs, vectors


def replay_primary_structure(
    decoded: v2m.PortalDecode,
    system: dict[str, Any],
) -> dict[str, Any]:
    """
    Replays the size/parent pre-pass ported from RVA 0x13AFE60.

    Normal generated entries receive parent=-1.
    Inserted PlanetSize-3 entries receive the index of the size-0 parent.
    """
    primary_count = int(system["primary_count"])
    final_count = primary_count + int(system["secondary_count"])
    internal_limit = int(system["internal_class_limit"])

    if system["special_seed_layout"] or system["force_six_special_bodies"]:
        sizes = [4] + [3] * max(0, final_count - 1)
        parents = [-1] + [0] * max(0, final_count - 1)
        return {
            "planet_sizes": sizes,
            "parent_indices": parents,
            "primary_sizes": sizes[:primary_count],
            "primary_parent_indices": parents[:primary_count],
            "trace": [],
            "special_layout": True,
        }

    _, rng = v2m.make_planet_mwc(decoded.tkseed)
    trace: list[dict[str, Any]] = []
    sizes: list[int] = []
    parents: list[int] = []
    generated = 0

    while generated < primary_count:
        parent_index = generated
        size_word = rng.draw(
            f"primary_size_{generated}",
            trace,
        )
        size_value = v2m.mulhi_u32(size_word, 3)
        sizes.append(size_value)
        parents.append(-1)
        generated += 1

        if size_value == 0 and v2m.CURRENT_BUILD_EXTRA_CLASS_FLAG:
            remaining = min(max(primary_count - generated, 0), 2)
            choice_word = rng.draw(
                f"primary_size_zero_choice_{parent_index}",
                trace,
            )
            extra_entries = v2m.mulhi_u32(
                choice_word,
                remaining + 1,
            )

            while extra_entries > 0:
                if generated == internal_limit - 1:
                    break
                sizes.append(3)
                parents.append(parent_index)
                generated += 1
                extra_entries -= 1

    # V2M's field source_class is now proven to be source PlanetSize.
    full_prediction = v2m.predict_planet_seeds(decoded, system)
    full_sizes = [
        int(body["source_class"])
        for body in sorted(
            full_prediction["bodies"],
            key=lambda body: int(body["slot"]),
        )
    ]

    if full_sizes[:primary_count] != sizes:
        raise RuntimeError(
            "Primary PlanetSize replay disagrees with the validated V2M "
            f"seed schedule: replay={sizes}, v2m={full_sizes[:primary_count]}"
        )

    full_parents = parents + [-1] * max(0, len(full_sizes) - len(parents))

    return {
        "planet_sizes": full_sizes,
        "parent_indices": full_parents,
        "primary_sizes": sizes,
        "primary_parent_indices": parents,
        "trace": trace,
        "special_layout": False,
    }


def calculate_entry_budget(
    system: dict[str, Any],
    structure: dict[str, Any],
) -> dict[str, Any]:
    star_type = int(system["star_type_raw"])
    primary_sizes = [
        int(value) for value in structure["primary_sizes"]
    ]
    primary_parents = [
        int(value) for value in structure["primary_parent_indices"]
    ]

    root_count = sum(parent == -1 for parent in primary_parents)
    moon_parent_buckets = sorted(
        {
            parent
            for size, parent in zip(primary_sizes, primary_parents)
            if size == 3 and parent >= 0
        }
    )

    draws: list[dict[str, Any]] = []
    draw_index = 0

    def consume(site: str, reason: str, slot: int | None = None) -> None:
        nonlocal draw_index
        draws.append(
            {
                "draw_index": draw_index,
                "site": site,
                "reason": reason,
                "slot": slot,
            }
        )
        draw_index += 1

    consume(
        "0x16C526F",
        "unconditional direct-RNG spread/orbit seed",
    )

    for slot, size_value in enumerate(primary_sizes):
        if size_value == 3:
            continue

        consume(
            "0x16C5704",
            "primary non-size3 orbit draw A",
            slot,
        )
        consume(
            "0x16C587D",
            "primary non-size3 orbit draw B",
            slot,
        )
        if root_count > 0:
            consume(
                "0x16C59DF",
                "primary root-distribution draw",
                slot,
            )

    for parent in moon_parent_buckets:
        consume(
            "0x16C5ABB",
            f"size3 parent bucket shuffle for parent {parent}",
        )

    if root_count > 0:
        consume(
            "0x16C5BDB",
            "root-primary selector",
        )

    supported = star_type in SUPPORTED_NORMAL_STAR_TYPES
    warning = ""
    if not supported:
        warning = (
            "StarType 4 uses an additional special-system branch beginning "
            "at RVA 0x16C6048; V2R deliberately does not claim that branch."
        )

    return {
        "entry_offset": draw_index,
        "supported_for_final_prediction": supported,
        "warning": warning,
        "root_count": root_count,
        "moon_parent_buckets": moon_parent_buckets,
        "draw_trace": draws,
    }


def parse_classes(value: str, expected: int) -> list[int]:
    values = [
        int(item.strip(), 0)
        for item in value.split(",")
        if item.strip()
    ]
    if len(values) != expected:
        raise ValueError(
            f"--classes requires {expected} comma-separated values; "
            f"received {len(values)}."
        )
    return values


def vector_for_portal(
    vectors_payload: dict[str, Any],
    portal: str,
    resolved: str,
) -> dict[str, Any] | None:
    for vector in vectors_payload["vectors"]:
        if vector["portal"] == portal or vector["resolved"] == resolved:
            return vector
    return None


def predict(
    portal: str,
    classes: list[int] | None,
    tables: dict[str, Any],
    catalogs: dict[str, Any],
    vectors_payload: dict[str, Any],
) -> dict[str, Any]:
    decoded = v2m.decode_portal(portal)
    system = v2m.predict_system(decoded)
    seed_prediction = v2m.predict_planet_seeds(decoded, system)
    structure = replay_primary_structure(decoded, system)
    budget = calculate_entry_budget(system, structure)

    known_vector = vector_for_portal(
        vectors_payload,
        decoded.input_portal,
        decoded.resolved_system_portal,
    )

    if classes is None and known_vector is not None:
        classes = [
            int(value) for value in known_vector["final_classes"]
        ]

    biome_result = None
    if (
        classes is not None
        and budget["supported_for_final_prediction"]
    ):
        vector = {
            "portal": decoded.input_portal,
            "resolved": decoded.resolved_system_portal,
            "tkseed": f"0x{decoded.tkseed:016X}",
            "star_type": int(system["star_type_raw"]),
            "primary_count": int(system["primary_count"]),
            "secondary_count": int(system["secondary_count"]),
            "final_classes": classes,
            "planet_sizes": structure["planet_sizes"],
        }
        simulation = v2q.simulate_schedule(
            vector,
            tables,
            catalogs,
            int(budget["entry_offset"]),
        )
        biome_result = {
            "classes_source": (
                "KNOWN_CONTROLLED_VECTOR"
                if known_vector is not None
                else "USER_SUPPLIED"
            ),
            "final_classes": classes,
            "simulation": simulation,
        }

    return {
        "version": VERSION,
        "mode": "OFFLINE_NO_NMS_PROCESS",
        "decoded": {
            "input_portal": decoded.input_portal,
            "resolved_system_portal": decoded.resolved_system_portal,
            "tkseed": f"0x{decoded.tkseed:016X}",
            "voxel_x": decoded.voxel_x,
            "voxel_y": decoded.voxel_y,
            "voxel_z": decoded.voxel_z,
            "ssi": decoded.supplied_ssi,
        },
        "system": {
            "primary_count": int(system["primary_count"]),
            "secondary_count": int(system["secondary_count"]),
            "final_count": int(system["final_count"]),
            "star_type_raw": int(system["star_type_raw"]),
            "star_colour_confirmed": system["star_colour_confirmed"],
        },
        "planet_structure": structure,
        "direct_rng_budget": budget,
        "planet_seeds": [
            {
                "slot": int(body["slot"]),
                "seed": body["seed_hex"],
                "planet_size": int(body["source_class"]),
            }
            for body in seed_prediction["bodies"]
        ],
        "biome_prediction": biome_result,
        "remaining_boundary": (
            "NONE_FOR_CONTROLLED_VECTOR"
            if biome_result is not None
            else "FINAL_CLASS_ARRAY_NOT_YET_ADDRESS_DERIVED"
        ),
    }


def self_test(
    tables: dict[str, Any],
    catalogs: dict[str, Any],
    vectors_payload: dict[str, Any],
) -> list[str]:
    lines: list[str] = []
    biome_total = 0
    subtype_total = 0

    for vector in vectors_payload["vectors"]:
        result = predict(
            vector["portal"],
            [int(value) for value in vector["final_classes"]],
            tables,
            catalogs,
            vectors_payload,
        )
        offset = int(result["direct_rng_budget"]["entry_offset"])
        expected_offset = int(vector["expected_entry_offset"])
        if offset != expected_offset:
            raise AssertionError(
                f"Entry offset mismatch for {vector['portal']}: "
                f"{offset} != {expected_offset}"
            )

        simulation = result["biome_prediction"]["simulation"]
        got_biomes = [
            int(body["biome"]) for body in simulation["bodies"]
        ]
        got_subtypes = [
            int(body["final_subtype"]) for body in simulation["bodies"]
        ]
        expected_biomes = [
            int(value) for value in vector["final_biomes"]
        ]
        expected_subtypes = [
            int(value) for value in vector["final_subtypes"]
        ]
        if got_biomes != expected_biomes:
            raise AssertionError(
                f"Biome mismatch for {vector['portal']}: "
                f"{got_biomes} != {expected_biomes}"
            )
        if got_subtypes != expected_subtypes:
            raise AssertionError(
                f"Subtype mismatch for {vector['portal']}: "
                f"{got_subtypes} != {expected_subtypes}"
            )

        count = len(expected_biomes)
        biome_total += count
        subtype_total += count
        lines.append(
            f"SYSTEM={vector['portal']} STATUS=PASS "
            f"CALCULATED_ENTRY_OFFSET={offset} "
            f"BIOMES={count}/{count} "
            f"FINAL_SUBTYPES={count}/{count} "
            f"PRIMARY_SIZES="
            f"{result['planet_structure']['primary_sizes']} "
            f"PRIMARY_PARENTS="
            f"{result['planet_structure']['primary_parent_indices']}"
        )

    lines.extend(
        [
            "KNOWN_SYSTEMS_MATCHED=2/2",
            f"CALCULATED_ENTRY_OFFSETS_MATCHED=2/2",
            f"FINAL_BIOMES_MATCHED={biome_total}/{biome_total}",
            f"FINAL_BIOME_SUBTYPES_MATCHED={subtype_total}/{subtype_total}",
            "ENTRY_OFFSET_SOLVED_FROM_OUTPUTS=False",
            "ENTRY_OFFSET_CALCULATED_FROM_ADDRESS_DERIVED_STRUCTURE=True",
        ]
    )
    return lines


def format_report(result: dict[str, Any]) -> str:
    decoded = result["decoded"]
    system = result["system"]
    structure = result["planet_structure"]
    budget = result["direct_rng_budget"]

    lines = [
        "FIBONACCI NMS DIRECT RNG BUDGET SOLVER V2R",
        f"Version={VERSION}",
        "Mode=OFFLINE_NO_NMS_PROCESS",
        "",
        "ADDRESS",
        "-------",
        f"input_portal={decoded['input_portal']}",
        f"resolved_system_portal={decoded['resolved_system_portal']}",
        f"tkseed={decoded['tkseed']}",
        f"ssi=0x{decoded['ssi']:03X}",
        f"voxel_x={decoded['voxel_x']}",
        f"voxel_y={decoded['voxel_y']}",
        f"voxel_z={decoded['voxel_z']}",
        "",
        "ADDRESS-DERIVED SYSTEM STRUCTURE",
        "--------------------------------",
        f"primary_count={system['primary_count']}",
        f"secondary_count={system['secondary_count']}",
        f"final_count={system['final_count']}",
        f"star_type_raw={system['star_type_raw']}",
        f"star_colour_confirmed={system['star_colour_confirmed']}",
        f"planet_sizes={structure['planet_sizes']}",
        f"primary_parent_indices={structure['primary_parent_indices']}",
        "",
        "DIRECT RNG DRAW BUDGET",
        "----------------------",
        f"calculated_biome_entry_offset={budget['entry_offset']}",
        f"root_count={budget['root_count']}",
        f"moon_parent_buckets={budget['moon_parent_buckets']}",
        f"normal_star_branch_supported="
        f"{budget['supported_for_final_prediction']}",
    ]

    if budget["warning"]:
        lines.append(f"WARNING={budget['warning']}")

    lines.append("DRAW_TRACE")
    for draw in budget["draw_trace"]:
        slot = (
            f" slot={draw['slot']}"
            if draw["slot"] is not None
            else ""
        )
        lines.append(
            f"{draw['draw_index']:03d} "
            f"site={draw['site']}{slot} "
            f"reason={draw['reason']}"
        )

    lines.extend(["", "PLANET SEEDS", "------------"])
    for body in result["planet_seeds"]:
        lines.append(
            f"slot={body['slot']} "
            f"PlanetSize={body['planet_size']} "
            f"seed={body['seed']}"
        )

    biome = result["biome_prediction"]
    lines.extend(["", "BIOME STATUS", "------------"])
    if biome is None:
        lines.extend(
            [
                "final_biome_prediction=NOT_RUN",
                "reason=FINAL_CLASS_ARRAY_NOT_YET_ADDRESS_DERIVED",
                "controlled_option=rerun with --classes C0,C1,...",
            ]
        )
    else:
        lines.append(f"classes_source={biome['classes_source']}")
        lines.append(f"final_classes={biome['final_classes']}")
        for body in biome["simulation"]["bodies"]:
            lines.append(
                f"slot={body['slot']} "
                f"Biome={body['biome']} "
                f"BiomeSubType={body['final_subtype']} "
                f"Class={body['final_class']} "
                f"PlanetSize={body['planet_size']}"
            )

    lines.extend(
        [
            "",
            "CURRENT STATUS",
            "--------------",
            "address_only_body_counts=IMPLEMENTED",
            "address_only_planet_sizes=IMPLEMENTED",
            "address_only_parent_indices=IMPLEMENTED",
            "address_only_planet_seeds=IMPLEMENTED",
            "address_only_biome_entry_offset=IMPLEMENTED_FOR_STARTYPE_0_TO_3",
            "exact_biome_subtype_with_known_or_supplied_classes=IMPLEMENTED",
            "address_only_final_class_assignment=NOT_YET_PORTED",
            "next_target=RVA_0x16C43E0_FINAL_CLASS_ASSIGNMENT_INPUTS",
        ]
    )

    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("portal", nargs="?")
    parser.add_argument("--classes")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    tables, catalogs, vectors = load_assets(base)

    if args.self_test:
        print("DIRECT_RNG_BUDGET_V2R_SELF_TEST=PASS")
        for line in self_test(tables, catalogs, vectors):
            print(line)
        return 0

    portal = args.portal or input(
        "Enter a 12-glyph portal address: "
    ).strip()

    decoded = v2m.decode_portal(portal)
    preview_system = v2m.predict_system(decoded)
    class_values = None
    if args.classes:
        class_values = parse_classes(
            args.classes,
            int(preview_system["final_count"]),
        )

    result = predict(
        portal,
        class_values,
        tables,
        catalogs,
        vectors,
    )

    output = (
        json.dumps(result, indent=2) + "\n"
        if args.json
        else format_report(result)
    )
    print(output, end="")

    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output, encoding="utf-8")
        print(f"REPORT={args.report}")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(3)
