#!/usr/bin/env python3
"""
FIBONACCI NMS LIVE COMPLETE WEATHER STATE REPLAY VALIDATOR V4C

Purpose
-------
Validate the exact child-seed-13 weather-index path against every planet in
the currently loaded system.

V4B closes:
- the biome/subtype-to-weighting-slot helper at 0x403420;
- the first child-seed-13 MWC weather draw;
- the 17-weight cumulative selector;
- both post-selection weather-index overrides in 0x1701630.

It compares the predicted final weather index to the actual live
planet+0x1D74 value.

Safety
------
Read-only process access only.
No process-memory writes, hooks, injection, breakpoints or target execution.
No game, save, MODS, settings, EXE or DLL writes.
"""
from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import math
import os
import struct
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

VERSION = "4C.0.0"
TAG = "live_complete_weather_state_replay_validator_v4c"
HERE = Path(__file__).resolve().parent
EXPECTED = json.loads(
    (HERE / "EXPECTED_WEATHER_REPLAY_V4B.json").read_text(encoding="utf-8")
)
RUNTIME_ROOT = HERE.parent / "data" / "runtime_maps"
V3D_CORE_PATH = HERE / "_fibonacci_v3d2_reader_core.py"
REPLAY_CORE_PATH = HERE / "_v3r_replay_core.py"

MASK32 = 0xFFFFFFFF
WEATHER_INDEX_NAMES = [
    "Clear_or_Default_0",
    "Weather_1",
    "Weather_2",
    "Weather_3",
    "Weather_4",
    "Weather_5",
    "Weather_6",
    "Weather_7",
    "Weather_8",
    "Weather_9",
    "Weather_10",
    "Weather_11",
    "Weather_12",
    "Weather_13",
    "Weather_14",
    "Weather_15",
    "Weather_16",
]


def now_iso() -> str:
    return datetime.now().astimezone().isoformat()


def stamp() -> str:
    return datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def i32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<i", data, offset)[0]


def process_u32(process, address: int, label: str) -> int:
    return struct.unpack(
        "<I",
        process.read_exact(address, 4, label),
    )[0]


def process_i32(process, address: int, label: str) -> int:
    return struct.unpack(
        "<i",
        process.read_exact(address, 4, label),
    )[0]


def process_u8(process, address: int, label: str) -> int:
    return process.read_exact(address, 1, label)[0]


def process_f32(process, address: int, label: str) -> float:
    return struct.unpack(
        "<f",
        process.read_exact(address, 4, label),
    )[0]


def generate_children(seed: int, replay) -> list[int]:
    state = replay.state_direct_64(seed)
    children: list[int] = []
    for _ in range(26):
        first = state.draw()
        second = state.draw()
        combined = ((second & MASK32) << 32) | (first & MASK32)
        children.append(replay.avalanche_mix_64(combined))
    return children


def exact_slot_helper(
    requested_subtype: int,
    pointer_values: list[int],
) -> tuple[int, str]:
    """
    Exact 0x403420 semantics.

    If requested subtype is in range and has a non-null weighting pointer,
    return it. Otherwise return the first non-null slot. If none exists,
    return zero.
    """
    count = len(pointer_values)
    if (
        requested_subtype >= 0
        and requested_subtype < count
        and pointer_values[requested_subtype] != 0
    ):
        return requested_subtype, "requested_slot_valid"

    for index, pointer in enumerate(pointer_values):
        if pointer != 0:
            return index, "fallback_first_nonnull"

    return 0, "fallback_zero_no_nonnull_slots"


def weighted_weather_index(
    weights: list[float],
    draw_word: int,
) -> tuple[int, dict[str, Any]]:
    if len(weights) != 17:
        raise RuntimeError(f"Expected 17 weather weights, got {len(weights)}")
    if not all(math.isfinite(value) for value in weights):
        raise RuntimeError("Weather vector contains non-finite values.")
    if any(value < 0.0 for value in weights):
        raise RuntimeError("Weather vector contains a negative weight.")

    epsilon = f32(EXPECTED["constants"]["float_epsilon"])
    unit = float(EXPECTED["constants"]["u32_to_unit_double"])

    total = f32(0.0)
    for value in weights:
        total = f32(total + f32(value))

    scaled_span = f32(total - epsilon)
    random_f32 = f32(float(draw_word & MASK32) * unit)
    threshold = f32(f32(random_f32 * scaled_span) + epsilon)

    cumulative = f32(0.0)
    selected = 0
    selected_found = False
    cumulative_trace = []
    for index, value in enumerate(weights):
        cumulative = f32(cumulative + f32(value))
        cumulative_trace.append(cumulative)
        if cumulative >= threshold:
            selected = index
            selected_found = True
            break

    return selected, {
        "sum_f32": total,
        "epsilon": epsilon,
        "random_f32": random_f32,
        "threshold_f32": threshold,
        "selected_found": selected_found,
        "cumulative_at_selection": cumulative,
        "cumulative_trace": cumulative_trace,
    }


def apply_weather_index_overrides(
    initial_index: int,
    planet_class: int,
    biome: int,
    special_weather_state: int,
) -> tuple[int, list[str]]:
    """
    Exact final writes to planet+0x1D74 in weather writer 0x1701630.

    Override A:
      class == 1, biome != 5 and selected index == 1 -> index 5

    Override B:
      class != 1, selected index == 2 and the selected +0x33EC state is 3
      -> index 13
    """
    index = int(initial_index)
    reasons: list[str] = []

    if planet_class == 1:
        if biome != 5 and index == 1:
            index = 5
            reasons.append("class1_non_biome5_index1_to_5")
    else:
        if index == 2 and special_weather_state == 3:
            index = 13
            reasons.append("index2_special_state3_to_13")

    return index, reasons



def exact_weighted_selector_any(
    weights: list[float],
    draw_word: int,
) -> tuple[int, dict[str, Any]]:
    if not weights:
        raise RuntimeError("Weighted selector received no weights.")
    if not all(math.isfinite(value) for value in weights):
        raise RuntimeError("Weighted selector contains a non-finite value.")
    if any(value < 0.0 for value in weights):
        raise RuntimeError("Weighted selector contains a negative weight.")

    epsilon = f32(EXPECTED["constants"]["float_epsilon"])
    unit = float(EXPECTED["constants"]["u32_to_unit_double"])

    total = f32(0.0)
    for value in weights:
        total = f32(total + f32(value))

    scaled_span = f32(total - epsilon)
    random_f32 = f32(float(draw_word & MASK32) * unit)
    threshold = f32(f32(random_f32 * scaled_span) + epsilon)

    cumulative = f32(0.0)
    selected = 0
    selected_found = False
    cumulative_trace: list[float] = []
    for index, value in enumerate(weights):
        cumulative = f32(cumulative + f32(value))
        cumulative_trace.append(cumulative)
        if cumulative >= threshold:
            selected = index
            selected_found = True
            break

    return selected, {
        "sum_f32": total,
        "epsilon": epsilon,
        "random_f32": random_f32,
        "threshold_f32": threshold,
        "selected_found": selected_found,
        "cumulative_at_selection": cumulative,
        "cumulative_trace": cumulative_trace,
    }


def draw_random_f32(state) -> tuple[int, float]:
    word = state.draw()
    unit = float(EXPECTED["constants"]["u32_to_unit_double"])
    return word, f32(float(word & MASK32) * unit)


def replay_complete_weather_state(
    state,
    *,
    biome: int,
    planet_class: int,
    weather_class: int,
    reality_class: int,
    weather_suppression: bool,
    global_force_weather: bool,
    context_special_mode: bool,
    context_suppression: bool,
    context_force_mode_3: bool,
    weather_config_count: int,
    weather_class_probabilities: list[float],
    config_fields: dict[str, float],
    reality_active_probability: float,
    reality_mode_probability: float,
) -> dict[str, Any]:
    """
    Exact control flow after the already-replayed first weather-index draw.

    The input state must point to the child-seed-13 stream immediately after
    draw 1. Later draws are consumed only on branches that execute them.
    """
    trace: list[dict[str, Any]] = []
    active = 0
    mode = 0
    primary_branch = ""

    if weather_suppression and biome != 15:
        primary_branch = "planet_39F1_suppression"
        active = 0
        mode = 0
    elif planet_class == 1:
        primary_branch = "planet_class_1_clear"
        active = 0
        mode = 0
    elif context_suppression:
        primary_branch = "live_context_suppression"
        active = 0
        mode = 0
    elif global_force_weather:
        primary_branch = "global_force_weather"
        active = 1
        mode = 2
    elif planet_class == 2:
        primary_branch = "planet_class_2_clear"
        active = 0
        mode = 0
    elif context_special_mode:
        primary_branch = "live_context_special_mode"
        active = 0
        mode = 2 + int(context_force_mode_3)
    elif weather_config_count == 0:
        primary_branch = "zero_weather_config_count"
        active = 0
        mode = 0
    else:
        primary_branch = "ordinary_probability_path"

        draw_word, random_value = draw_random_f32(state)
        probability = float(weather_class_probabilities[weather_class])
        active = int(probability > random_value)
        trace.append({
            "draw_role": "weather_active_probability",
            "word": f"0x{draw_word:08X}",
            "random_f32": random_value,
            "threshold": probability,
            "pass": bool(active),
        })

        draw_word, random_value = draw_random_f32(state)
        mode_one_probability = float(config_fields["field_BD8"])
        mode_one = mode_one_probability > random_value
        trace.append({
            "draw_role": "weather_mode_1_probability",
            "word": f"0x{draw_word:08X}",
            "random_f32": random_value,
            "threshold": mode_one_probability,
            "pass": mode_one,
        })

        if mode_one:
            mode = 1
        else:
            draw_word, random_value = draw_random_f32(state)
            mode_two_probability = float(config_fields["field_BD4"])
            mode_two_probability_pass = mode_two_probability > random_value
            mode = 2 if (mode_two_probability_pass or active == 1) else 0
            trace.append({
                "draw_role": "weather_mode_2_probability",
                "word": f"0x{draw_word:08X}",
                "random_f32": random_value,
                "threshold": mode_two_probability,
                "probability_pass": mode_two_probability_pass,
                "active_fallback": active == 1,
                "result_mode": mode,
            })

        if context_force_mode_3:
            mode = 3

    # Reality-class-2 post-branch override. These draws are consumed even when
    # the primary branch cleared or forced the fields.
    if reality_class == 2:
        if planet_class == 1:
            active = 1

        draw_word, random_value = draw_random_f32(state)
        reality_active_pass = reality_active_probability > random_value
        if reality_active_pass:
            active = 1
        trace.append({
            "draw_role": "reality_class_2_active_override",
            "word": f"0x{draw_word:08X}",
            "random_f32": random_value,
            "threshold": reality_active_probability,
            "pass": reality_active_pass,
        })

        draw_word, random_value = draw_random_f32(state)
        reality_mode_pass = reality_mode_probability > random_value
        if reality_mode_pass:
            mode = 2
        trace.append({
            "draw_role": "reality_class_2_mode_override",
            "word": f"0x{draw_word:08X}",
            "random_f32": random_value,
            "threshold": reality_mode_probability,
            "pass": reality_mode_pass,
        })

    # Final biome overrides and the four-way weather-intensity selector.
    if biome == 15:
        active = 1
        mode = 0
        flag = 1
        intensity = 3
        intensity_branch = "gas_giant_fixed"
    else:
        if biome in (6, 7):
            active = 0
            mode = 0

        flag = int(biome != 6)
        intensity = 3

        if biome == 14:
            intensity = 0
            intensity_branch = "waterworld_fixed_zero"
        elif biome in (6, 15):
            intensity_branch = "fixed_no_intensity_draw"
        else:
            intensity_weights = [
                float(config_fields["field_BC0"]),
                float(config_fields["field_BC4"]),
                float(config_fields["field_BC8"]),
                float(config_fields["field_BCC"]),
            ]
            draw_word = state.draw()
            selected, selector_audit = exact_weighted_selector_any(
                intensity_weights,
                draw_word,
            )
            intensity = selected if selector_audit["selected_found"] else 3
            intensity_branch = "four_weight_selector"
            trace.append({
                "draw_role": "weather_intensity_selector",
                "word": f"0x{draw_word:08X}",
                "weights": intensity_weights,
                "selected": selected,
                "selected_found": selector_audit["selected_found"],
                "threshold_f32": selector_audit["threshold_f32"],
                "sum_f32": selector_audit["sum_f32"],
            })

    return {
        "predicted_weather_active": active,
        "predicted_weather_mode": mode,
        "predicted_weather_flag": flag,
        "predicted_weather_intensity": intensity,
        "primary_branch": primary_branch,
        "intensity_branch": intensity_branch,
        "later_draw_count": len(trace),
        "later_draw_trace": trace,
    }


def validate_live_signatures(process) -> dict[str, Any]:
    rows = []
    for name, item in EXPECTED["signatures"].items():
        rva = int(item["rva"])
        length = int(item["length"])
        observed = process.read_exact(
            process.module_base + rva,
            length,
            f"V4B {name} signature",
        )
        observed_hash = sha256(observed)
        rows.append({
            "name": name,
            "rva": f"0x{rva:X}",
            "length": length,
            "expected_sha256": item["sha256"],
            "observed_sha256": observed_hash,
            "match": observed_hash == item["sha256"],
        })
    return {
        "rows": rows,
        "match_count": sum(1 for row in rows if row["match"]),
        "count": len(rows),
        "all_match": all(row["match"] for row in rows),
    }


def capture_and_replay() -> dict[str, Any]:
    core = load_module("v4b_v3d_core", V3D_CORE_PATH)
    replay = load_module("v4b_replay_core", REPLAY_CORE_PATH)
    offsets = EXPECTED["offsets"]
    constants = EXPECTED["constants"]

    with core.LiveProcess() as process:
        base_validation = process.validate_build()
        signatures = validate_live_signatures(process)
        if not signatures["all_match"]:
            raise RuntimeError("One or more V4B local code signatures mismatch.")

        chain = process.resolve_pointer_chain()
        snapshot, readable = process.read_chunked(
            chain.solar_object_address,
            core.SOLAR_SNAPSHOT_SIZE,
        )
        if readable < core.RESOLVED_PACKED_ADDRESS_OFFSET + 8:
            raise RuntimeError("Persistent solar snapshot is too short.")

        final_count, star_type, records = core.read_planet_inputs(snapshot)
        layout = core.detect_cluster_layout(snapshot, records)
        best = layout["best"]
        if best is None or not best["complete"]:
            raise RuntimeError(
                "The complete 0xD9070 planet cluster layout was not found."
            )

        generator = (
            chain.solar_object_address
            + int(offsets["planet_generator_from_solar"])
        )

        global_special_index = struct.unpack(
            "<i",
            process.read_exact(
                process.module_base
                + int(EXPECTED["rvas"]["global_special_weather_index"]),
                4,
                "global special weather index",
            ),
        )[0]

        packed_system_address = core.u64(
            snapshot,
            core.RESOLVED_PACKED_ADDRESS_OFFSET,
        )

        global_force_weather = bool(process_u8(
            process,
            process.module_base
            + int(EXPECTED["rvas"]["global_force_weather"]),
            "global force-weather byte",
        ))
        reality_active_probability = process_f32(
            process,
            process.module_base
            + int(EXPECTED["rvas"]["global_reality_branch_active_probability"]),
            "reality-class active probability",
        )
        reality_mode_probability = process_f32(
            process,
            process.module_base
            + int(EXPECTED["rvas"]["global_reality_branch_mode_probability"]),
            "reality-class mode probability",
        )
        weather_class_probabilities = list(struct.unpack(
            "<8f",
            process.read_exact(
                process.module_base
                + int(EXPECTED["rvas"]["global_weather_class_probability_table"]),
                8 * 4,
                "global weather-class probability table",
            ),
        ))

        global_game = (
            chain.singleton_base_pointer
            + int(offsets["global_game_object_addend"])
        )
        game_active_byte_1 = process_u8(
            process,
            global_game + int(offsets["game_active_byte_1"]),
            "global game active byte 1",
        )
        game_active_byte_2 = process_u8(
            process,
            global_game + int(offsets["game_active_byte_2"]),
            "global game active byte 2",
        )
        game_context_active = bool(
            game_active_byte_1 or game_active_byte_2
        )
        game_current_system_address = process.read_u64(
            global_game + int(offsets["game_current_system_address"]),
            "global game current-system address",
        )
        game_context_matches_system = (
            game_current_system_address == packed_system_address
        )

        context_special_mode = False
        context_suppression = False
        context_force_mode_3 = False
        if game_context_active:
            context_force_mode_3 = bool(process_u8(
                process,
                global_game + int(offsets["game_context_force_mode_3"]),
                "global context force-mode-3 byte",
            ))
            if game_context_matches_system:
                context_special_mode = (
                    process_i32(
                        process,
                        global_game + int(offsets["game_mode_a"]),
                        "global game mode A",
                    ) == 3
                    or process_i32(
                        process,
                        global_game + int(offsets["game_mode_b"]),
                        "global game mode B",
                    ) == 3
                )
                context_suppression = bool(process_u8(
                    process,
                    global_game
                    + int(offsets["game_context_suppression"]),
                    "global context weather-suppression byte",
                ))

        weather_config_count = process_u32(
            process,
            generator + int(offsets["weather_config_count"]),
            "weather configuration count",
        )
        weather_config_pointer_array = process.read_u64(
            generator + int(offsets["weather_config_pointer_array"]),
            "weather configuration pointer array",
        )

        planet_rows = []
        for record in records:
            slot = int(record["slot"])
            anchor = int(best["anchors_by_slot"][str(slot)])
            cluster = snapshot[
                anchor:anchor + core.PLANET_CLUSTER_STRIDE
            ]
            planet_base = int(offsets["planet_data_in_cluster"])

            live_biome = i32(cluster, planet_base + int(offsets["biome"]))
            live_subtype = i32(cluster, planet_base + int(offsets["subtype"]))
            planet_class = i32(
                cluster, planet_base + int(offsets["planet_class"])
            )
            weather_class = i32(
                cluster, planet_base + int(offsets["weather_class"])
            )
            actual_weather_index = i32(
                cluster, planet_base + int(offsets["weather_index"])
            )
            actual_weather_active = i32(
                cluster, planet_base + int(offsets["weather_active"])
            )
            actual_weather_mode = i32(
                cluster, planet_base + int(offsets["weather_mode"])
            )
            actual_weather_flag = i32(
                cluster, planet_base + int(offsets["weather_flag"])
            )
            actual_weather_intensity = i32(
                cluster, planet_base + int(offsets["weather_intensity"])
            )

            if live_biome != int(record["biome"]):
                raise RuntimeError(
                    f"Planet {slot}: cluster biome {live_biome} does not "
                    f"match input biome {record['biome']}."
                )
            if live_subtype != int(record["biome_subtype"]):
                raise RuntimeError(
                    f"Planet {slot}: cluster subtype {live_subtype} does not "
                    f"match input subtype {record['biome_subtype']}."
                )

            if not (0 <= live_biome < 17):
                sanitized_biome = 0
            else:
                sanitized_biome = live_biome

            header_count_address = (
                generator
                + int(offsets["weather_header_count_base"])
                + sanitized_biome
                * int(offsets["weather_header_stride"])
            )
            header_pointer_address = (
                generator
                + int(offsets["weather_header_pointer_base"])
                + sanitized_biome
                * int(offsets["weather_header_stride"])
            )
            table_count = process_u32(
                process,
                header_count_address,
                f"planet {slot} weather subtype table count",
            )
            table_pointer = process.read_u64(
                header_pointer_address,
                f"planet {slot} weather subtype table pointer",
            )

            if table_count > 256:
                raise RuntimeError(
                    f"Planet {slot}: implausible weather slot count "
                    f"{table_count}."
                )
            if table_count > 0:
                raw_pointers = process.read_exact(
                    table_pointer,
                    table_count * 8,
                    f"planet {slot} weather subtype pointer array",
                )
                pointer_values = list(
                    struct.unpack(f"<{table_count}Q", raw_pointers)
                )
            else:
                pointer_values = []

            selected_slot, slot_reason = exact_slot_helper(
                live_subtype, pointer_values
            )
            selected_pointer = (
                pointer_values[selected_slot]
                if 0 <= selected_slot < len(pointer_values)
                else 0
            )
            if selected_pointer == 0:
                raise RuntimeError(
                    f"Planet {slot}: selected weather weighting pointer "
                    "is null."
                )

            if not (0 <= weather_class < 5):
                raise RuntimeError(
                    f"Planet {slot}: weather class {weather_class} is "
                    "outside the captured 0..4 range."
                )

            vector_address = (
                selected_pointer
                + int(offsets["weather_vector_base"])
                + weather_class * int(offsets["weather_class_stride"])
            )
            weights = list(struct.unpack(
                "<17f",
                process.read_exact(
                    vector_address,
                    17 * 4,
                    f"planet {slot} weather weight vector",
                ),
            ))

            children = generate_children(int(record["seed"]), replay)
            child_13 = children[12]
            state = replay.state_direct_64(child_13)
            draw_word = state.draw()
            initial_index, selector_audit = weighted_weather_index(
                weights, draw_word
            )

            special_offset = (
                planet_base
                + int(offsets["special_weather_array"])
                + global_special_index
                * int(offsets["special_weather_stride"])
            )
            special_weather_state = i32(cluster, special_offset)

            predicted_final, override_reasons = apply_weather_index_overrides(
                initial_index,
                planet_class,
                live_biome,
                special_weather_state,
            )

            if not (0 <= predicted_final < weather_config_count):
                raise RuntimeError(
                    f"Planet {slot}: predicted weather index "
                    f"{predicted_final} is outside config count "
                    f"{weather_config_count}."
                )

            weather_config_pointer = process.read_u64(
                weather_config_pointer_array + predicted_final * 8,
                f"planet {slot} weather config pointer",
            )
            config_fields = {
                f"field_{offset:03X}": process_f32(
                    process,
                    weather_config_pointer + offset,
                    f"planet {slot} weather config +0x{offset:X}",
                )
                for offset in (0xBC0, 0xBC4, 0xBC8, 0xBCC, 0xBD0, 0xBD4, 0xBD8)
            }

            weather_suppression = bool(
                cluster[
                    planet_base
                    + int(offsets["planet_weather_suppression"])
                ]
            )
            reality_index = int(record["reality_index"])
            reality_class_table = list(
                EXPECTED["constants"]["reality_class_table"]
            )
            reality_class = reality_class_table[reality_index % 20]

            complete_state = replay_complete_weather_state(
                state,
                biome=live_biome,
                planet_class=planet_class,
                weather_class=weather_class,
                reality_class=reality_class,
                weather_suppression=weather_suppression,
                global_force_weather=global_force_weather,
                context_special_mode=context_special_mode,
                context_suppression=context_suppression,
                context_force_mode_3=context_force_mode_3,
                weather_config_count=weather_config_count,
                weather_class_probabilities=weather_class_probabilities,
                config_fields=config_fields,
                reality_active_probability=reality_active_probability,
                reality_mode_probability=reality_mode_probability,
            )

            active_exact = (
                complete_state["predicted_weather_active"]
                == actual_weather_active
            )
            mode_exact = (
                complete_state["predicted_weather_mode"]
                == actual_weather_mode
            )
            flag_exact = (
                complete_state["predicted_weather_flag"]
                == actual_weather_flag
            )
            intensity_exact = (
                complete_state["predicted_weather_intensity"]
                == actual_weather_intensity
            )
            complete_exact = (
                predicted_final == actual_weather_index
                and active_exact
                and mode_exact
                and flag_exact
                and intensity_exact
            )

            planet_rows.append({
                "slot": slot,
                "seed_hex": f"0x{int(record['seed']):016X}",
                "child_13_seed_hex": f"0x{child_13:016X}",
                "biome": live_biome,
                "subtype": live_subtype,
                "planet_class_31E0": planet_class,
                "weather_class_31E8": weather_class,
                "slot_table_count": table_count,
                "resolved_weighting_slot": selected_slot,
                "slot_resolution": slot_reason,
                "weighting_pointer": f"0x{selected_pointer:X}",
                "weight_vector_address": f"0x{vector_address:X}",
                "weight_sum_f32": selector_audit["sum_f32"],
                "first_weather_draw_word": f"0x{draw_word:08X}",
                "threshold_f32": selector_audit["threshold_f32"],
                "initial_predicted_weather_index": initial_index,
                "special_weather_global_index": global_special_index,
                "special_weather_state": special_weather_state,
                "override_reasons": " | ".join(override_reasons),
                "predicted_final_weather_index": predicted_final,
                "actual_weather_index": actual_weather_index,
                "exact": predicted_final == actual_weather_index,
                "actual_weather_active_1D70": actual_weather_active,
                "actual_weather_mode_1D68": actual_weather_mode,
                "actual_weather_flag_1D50": actual_weather_flag,
                "actual_weather_intensity_1D60": actual_weather_intensity,
                "reality_index": reality_index,
                "reality_class": reality_class,
                "weather_suppression_39F1": weather_suppression,
                "weather_config_pointer": f"0x{weather_config_pointer:X}",
                **config_fields,
                **complete_state,
                "active_exact": active_exact,
                "mode_exact": mode_exact,
                "flag_exact": flag_exact,
                "intensity_exact": intensity_exact,
                "complete_weather_state_exact": complete_exact,
                "weights": weights,
                "selector_audit": selector_audit,
            })

        exact_count = sum(1 for row in planet_rows if row["exact"])
        active_exact_count = sum(
            1 for row in planet_rows if row["active_exact"]
        )
        mode_exact_count = sum(
            1 for row in planet_rows if row["mode_exact"]
        )
        flag_exact_count = sum(
            1 for row in planet_rows if row["flag_exact"]
        )
        intensity_exact_count = sum(
            1 for row in planet_rows if row["intensity_exact"]
        )
        complete_exact_count = sum(
            1
            for row in planet_rows
            if row["complete_weather_state_exact"]
        )

        status = (
            "PASS_EXACT_COMPLETE_WEATHER_STATE_REPLAY_CURRENT_SYSTEM"
            if complete_exact_count == len(planet_rows)
            else "PASS_PARTIAL_COMPLETE_WEATHER_STATE_REPLAY_WITH_MISMATCHES"
        )

        return {
            "version": VERSION,
            "tag": TAG,
            "timestamp": now_iso(),
            "status": status,
            "safety": {
                "process_access": "PROCESS_VM_READ_ONLY",
                "process_memory_writes": False,
                "hooks_breakpoints_injection": False,
                "target_code_execution": False,
                "thread_suspension": False,
                "game_file_writes": False,
                "save_writes": False,
                "mods_settings_writes": False,
            },
            "process": {
                "pid": process.pid,
                "module_base": f"0x{process.module_base:X}",
                "module_size": process.module_size,
                "module_path": process.module_path,
            },
            "base_validation": base_validation,
            "local_signatures": signatures,
            "pointer_chain": {
                "descriptor": f"0x{chain.descriptor_address:X}",
                "singleton_base": f"0x{chain.singleton_base_pointer:X}",
                "main_object": f"0x{chain.main_object_address:X}",
                "solar_object": f"0x{chain.solar_object_address:X}",
                "planet_generator": f"0x{generator:X}",
            },
            "current_system": core.decode_packed_address(
                core.u64(snapshot, core.RESOLVED_PACKED_ADDRESS_OFFSET)
            ),
            "planet_count": len(planet_rows),
            "exact_count": exact_count,
            "active_exact_count": active_exact_count,
            "mode_exact_count": mode_exact_count,
            "flag_exact_count": flag_exact_count,
            "intensity_exact_count": intensity_exact_count,
            "complete_exact_count": complete_exact_count,
            "global_special_weather_index": global_special_index,
            "weather_config_count": weather_config_count,
            "global_weather_context": {
                "packed_system_address": f"0x{packed_system_address:016X}",
                "global_force_weather": global_force_weather,
                "game_context_active": game_context_active,
                "game_active_byte_1": game_active_byte_1,
                "game_active_byte_2": game_active_byte_2,
                "game_current_system_address": (
                    f"0x{game_current_system_address:016X}"
                ),
                "game_context_matches_system": game_context_matches_system,
                "context_special_mode": context_special_mode,
                "context_suppression": context_suppression,
                "context_force_mode_3": context_force_mode_3,
                "reality_active_probability": reality_active_probability,
                "reality_mode_probability": reality_mode_probability,
                "weather_class_probabilities": weather_class_probabilities,
            },
            "planet_rows": planet_rows,
            "claim_boundary": {
                "subtype_slot_helper_exact": True,
                "child_13_initial_weather_selector_exact": True,
                "weather_index_overrides_exact": True,
                "weather_index_exact_for_current_system": (
                    exact_count == len(planet_rows)
                ),
                "weather_active_and_intensity_replayed": True,
                "complete_weather_state_exact_for_current_system": (
                    complete_exact_count == len(planet_rows)
                ),
                "complete_weather_replay_claimed": (
                    complete_exact_count == len(planet_rows)
                ),
                "complete_address_only_predictor_claimed": False,
                "next_phase": (
                    "Integrate the complete child-seed-13 weather replay "
                    "with the ten-system corpus and continue deriving the "
                    "earlier address-derived weather-class and suppression "
                    "inputs."
                ),
            },
        }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = [
        key for key in rows[0].keys()
        if key not in {"weights", "selector_audit"}
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in fields})


def write_outputs(result: dict[str, Any], output: Path) -> Path:
    output.mkdir(parents=True, exist_ok=True)
    json_path = output / "live_complete_weather_state_replay_validator_v4c.json"
    json_path.write_text(json.dumps(result, indent=2), encoding="utf-8")

    rows = result.get("planet_rows", [])
    write_csv(output / "complete_weather_state_exact_audit_v4c.csv", rows)
    write_csv(
        output / "local_signature_validation_v4c.csv",
        result.get("local_signatures", {}).get("rows", []),
    )

    mismatch_rows = [
        row for row in rows
        if not row.get("complete_weather_state_exact")
    ]
    write_csv(output / "complete_weather_state_mismatches_v4c.csv", mismatch_rows)

    context = result.get("global_weather_context", {})
    report = f"""FIBONACCI NMS LIVE COMPLETE WEATHER STATE REPLAY VALIDATOR V4C
Timestamp={result['timestamp']}
Version={VERSION}

RESULT
------
STATUS={result['status']}
ERROR={result.get('error', 'NONE')}
MODE=LIVE_READ_ONLY_COMPLETE_CHILD_13_WEATHER_STATE_REPLAY
NMS_PROCESS_REQUIRED=True
PROCESS_MEMORY_WRITES=False
GAME_FILE_WRITES=False
SAVE_WRITES=False
MOD_WRITES=False
HOOKS_OR_INJECTION=False
COMPLETE_ADDRESS_ONLY_PREDICTOR_CLAIMED=False

STATIC AND LIVE IDENTITY
------------------------
LOCAL_SIGNATURES_MATCHED={result.get('local_signatures', {}).get('match_count', 0)}/{result.get('local_signatures', {}).get('count', 0)}

CURRENT SYSTEM
--------------
PORTAL={result.get('current_system', {}).get('canonical_planet_zero_portal', 'UNKNOWN')}
PLANET_COUNT={result.get('planet_count', 0)}
WEATHER_INDEX_EXACT={result.get('exact_count', 0)}/{result.get('planet_count', 0)}
WEATHER_ACTIVE_EXACT={result.get('active_exact_count', 0)}/{result.get('planet_count', 0)}
WEATHER_MODE_EXACT={result.get('mode_exact_count', 0)}/{result.get('planet_count', 0)}
WEATHER_FLAG_EXACT={result.get('flag_exact_count', 0)}/{result.get('planet_count', 0)}
WEATHER_INTENSITY_EXACT={result.get('intensity_exact_count', 0)}/{result.get('planet_count', 0)}
COMPLETE_WEATHER_STATE_EXACT={result.get('complete_exact_count', 0)}/{result.get('planet_count', 0)}

LIVE CONTEXT INPUTS
-------------------
GLOBAL_FORCE_WEATHER={context.get('global_force_weather', 'UNKNOWN')}
GAME_CONTEXT_ACTIVE={context.get('game_context_active', 'UNKNOWN')}
GAME_CONTEXT_MATCHES_SYSTEM={context.get('game_context_matches_system', 'UNKNOWN')}
CONTEXT_SPECIAL_MODE={context.get('context_special_mode', 'UNKNOWN')}
CONTEXT_SUPPRESSION={context.get('context_suppression', 'UNKNOWN')}
CONTEXT_FORCE_MODE_3={context.get('context_force_mode_3', 'UNKNOWN')}
REALITY_ACTIVE_PROBABILITY={context.get('reality_active_probability', 'UNKNOWN')}
REALITY_MODE_PROBABILITY={context.get('reality_mode_probability', 'UNKNOWN')}
WEATHER_CLASS_PROBABILITIES={context.get('weather_class_probabilities', [])}

EXACTLY REPLAYED
----------------
WEATHER_INDEX=child-seed-13 draw 1 plus both post-selection overrides
WEATHER_ACTIVE=branch-specific global table draw and reality override
WEATHER_MODE=per-weather +0xBD8/+0xBD4 draws and context overrides
WEATHER_FLAG=final biome rule
WEATHER_INTENSITY=per-weather +0xBC0..+0xBCC four-weight draw
DRAW_SCHEDULE=branch-dependent and preserved exactly

PLANET AUDIT
------------
"""
    for row in rows:
        report += (
            f"SLOT={row['slot']} "
            f"BIOME={row['biome']} "
            f"SUBTYPE={row['subtype']} "
            f"INDEX={row['predicted_final_weather_index']}/{row['actual_weather_index']} "
            f"ACTIVE={row['predicted_weather_active']}/{row['actual_weather_active_1D70']} "
            f"MODE={row['predicted_weather_mode']}/{row['actual_weather_mode_1D68']} "
            f"FLAG={row['predicted_weather_flag']}/{row['actual_weather_flag_1D50']} "
            f"INTENSITY={row['predicted_weather_intensity']}/{row['actual_weather_intensity_1D60']} "
            f"BRANCH={row['primary_branch']} "
            f"COMPLETE_EXACT={row['complete_weather_state_exact']}\\n"
        )

    report += f"""
INTERPRETATION
--------------
V4C replays the entire 0x1701630 weather writer for the loaded system,
including all conditionally consumed child-seed-13 draws.

The replay includes live global/context inputs only where the game itself
uses them. The planet-generation RNG and weather-table selection are still
reproduced independently from the planet seed and captured static tables.

A pass closes the weather writer for the current system. It does not yet
mean an arbitrary portal address can be fully predicted, because earlier
inputs such as Biome, BiomeSubType, planet class, weather class and the
0x39F1 suppression byte must also be generated from the address.

NEXT PHASE
----------
Integrate this exact weather writer into the ten-system corpus model, then
derive the remaining earlier weather-class and suppression inputs from their
own child-seed writers. Continue the sentinel, deep-water and scrap-world
branches needed to collapse V3W's hidden optional schedules.

OUTPUT FILES
------------
{output / 'ATLAS_APF_RESULT_COMPLETE_WEATHER_STATE_V4C.txt'}
{json_path}
{output / 'complete_weather_state_exact_audit_v4c.csv'}
{output / 'complete_weather_state_mismatches_v4c.csv'}
{output / 'local_signature_validation_v4c.csv'}
"""

    report_path = output / "ATLAS_APF_RESULT_COMPLETE_WEATHER_STATE_V4C.txt"
    report_path.write_text(report, encoding="utf-8")
    return report_path


def main() -> int:
    output = RUNTIME_ROOT / f"{TAG}_{stamp()}"
    try:
        result = capture_and_replay()
    except Exception as exc:
        result = {
            "version": VERSION,
            "tag": TAG,
            "timestamp": now_iso(),
            "status": f"ERROR_{type(exc).__name__}",
            "error": str(exc),
            "local_signatures": {"rows": [], "match_count": 0, "count": 0},
            "planet_rows": [],
            "planet_count": 0,
            "exact_count": 0,
        }

    report = write_outputs(result, output)
    print(f"STATUS={result['status']}")
    print(f"OUTPUT_DIR={output}")
    print(f"REPORT={report}")
    if result.get("error"):
        print(f"ERROR={result['error']}")
    return 0 if str(result["status"]).startswith("PASS_") else 1


if __name__ == "__main__":
    raise SystemExit(main())
