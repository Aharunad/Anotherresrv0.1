#!/usr/bin/env python3
"""
FIBONACCI NMS ADDRESS-ONLY FINAL BIOME PREDICTOR V2V

V2V adds the exact ForceContinents postprocess missing from V2S.

Pipeline:
12-glyph portal address
  -> counts / StarType
  -> PlanetSize / parent structure
  -> exact planet seeds
  -> final Class
  -> weighted Biome / BiomeSubType
  -> ForceContinents postprocess
  -> final live Biome / BiomeSubType

ForceContinents branch
----------------------
For each pre-postprocess Biome-6 body, in slot order:

1. Draw from an independent MWC stream initialized from TkSeed.
2. If the word is below 0x80000000 (threshold 0.5):
     Biome 6 -> Biome 7
     ForceContinents = true
3. Draw again.
4. index = mulhi_u32(word, 11)
5. BiomeSubType = [3,4,5,6,7,8,9,10,11,12,13][index]

The independent stream only advances for pre-postprocess Biome-6 bodies.
It does not shift the main weighted-biome RNG stream.

Validation:
* original controlled systems: 6/6 final bodies
* first blind V2T system: 25/25 critical fields
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import fibonacci_nms_address_only_biome_subtype_v2s as v2s

VERSION = "2V.0.0"
MASK32 = 0xFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899
FORCE_CONTINENTS_THRESHOLD = 0.5
FORCE_CONTINENTS_WORD_CUTOFF = 0x80000000
BIOME7_UNIFORM_SUBTYPES = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]


def initial_mwc(tkseed: int) -> tuple[int, int]:
    low = tkseed & MASK32
    high = (tkseed >> 32) & MASK32
    rotated = ((low >> 16) | ((low << 16) & MASK32)) & MASK32
    value = low if low != 0 else 1
    carry = (rotated ^ high ^ low) & MASK32
    return value, carry


def mwc_draw(value: int, carry: int) -> tuple[int, int, int]:
    total = (
        MWC_MULTIPLIER * (value & MASK32)
        + (carry & MASK32)
    )
    word = total & MASK32
    new_carry = (total >> 32) & MASK32
    return word, word, new_carry


def mulhi_u32(a: int, b: int) -> int:
    return ((a & MASK32) * (b & MASK32) >> 32) & MASK32


def apply_force_continents(
    tkseed: int,
    bodies: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    value, carry = initial_mwc(tkseed)
    trace: list[dict[str, Any]] = []

    for body in sorted(bodies, key=lambda row: int(row["slot"])):
        body["pre_postprocess_biome"] = body["biome"]
        body["pre_postprocess_biome_subtype"] = body["biome_subtype"]
        body["force_continents"] = False

        if body["biome"] != 6:
            continue

        roll_word, value, carry = mwc_draw(value, carry)
        convert = roll_word < FORCE_CONTINENTS_WORD_CUTOFF

        row: dict[str, Any] = {
            "slot": int(body["slot"]),
            "roll_word": f"0x{roll_word:08X}",
            "roll_probability": roll_word / 4294967296.0,
            "threshold": FORCE_CONTINENTS_THRESHOLD,
            "conversion": convert,
            "pre_biome": 6,
            "pre_subtype": body["biome_subtype"],
        }

        if convert:
            subtype_word, value, carry = mwc_draw(value, carry)
            catalog_index = mulhi_u32(
                subtype_word,
                len(BIOME7_UNIFORM_SUBTYPES),
            )
            final_subtype = BIOME7_UNIFORM_SUBTYPES[catalog_index]

            body["biome"] = 7
            body["biome_subtype"] = final_subtype
            body["force_continents"] = True

            row.update(
                {
                    "subtype_word": f"0x{subtype_word:08X}",
                    "uniform_catalog_index": catalog_index,
                    "final_biome": 7,
                    "final_subtype": final_subtype,
                    "force_continents": True,
                }
            )
        else:
            row.update(
                {
                    "final_biome": body["biome"],
                    "final_subtype": body["biome_subtype"],
                    "force_continents": False,
                }
            )

        trace.append(row)

    return trace


def predict(
    portal: str,
    tables: dict[str, Any],
    catalogs: dict[str, Any],
    vectors: dict[str, Any],
    galaxy_index: int = 0,
) -> dict[str, Any]:
    result = v2s.predict(portal, tables, catalogs, vectors, galaxy_index)
    result = json.loads(json.dumps(result))
    result["version"] = VERSION

    if result["prediction_supported"]:
        tkseed = int(result["address"]["tkseed"], 16)
        trace = apply_force_continents(tkseed, result["bodies"])
    else:
        trace = []

    result["force_continents_postprocess"] = {
        "implemented": True,
        "threshold": FORCE_CONTINENTS_THRESHOLD,
        "word_cutoff": f"0x{FORCE_CONTINENTS_WORD_CUTOFF:08X}",
        "biome7_uniform_subtypes": BIOME7_UNIFORM_SUBTYPES,
        "trace": trace,
    }

    result["pipeline_status"] = {
        "standard_star_type_0_to_3": "IMPLEMENTED",
        "force_continents_postprocess": "IMPLEMENTED",
        "star_type_4_special_route": "NOT_CLAIMED",
        "runtime_global_class_mode_3": "NOT_CLAIMED",
    }
    return result


def compare_blind_vector(
    result: dict[str, Any],
    vector: dict[str, Any],
) -> tuple[int, int, list[str]]:
    matches = 0
    checks = 0
    failures: list[str] = []

    def check(name: str, expected: Any, actual: Any) -> None:
        nonlocal matches, checks
        checks += 1
        if expected == actual:
            matches += 1
        else:
            failures.append(
                f"{name}: expected={expected} actual={actual}"
            )

    check(
        "resolved_system_portal",
        vector["resolved_system_portal"],
        result["address"]["resolved_system_portal"],
    )
    check("tkseed", vector["tkseed"].upper(), result["address"]["tkseed"].upper())
    check(
        "final_count",
        vector["final_count"],
        result["system"]["final_count"],
    )
    check(
        "primary_count",
        vector["primary_count"],
        result["system"]["primary_count"],
    )
    check(
        "secondary_count",
        vector["secondary_count"],
        result["system"]["secondary_count"],
    )
    check(
        "star_type",
        vector["star_type"],
        result["system"]["star_type_raw"],
    )
    # Match V2T's seventh system-level critical check.
    check(
        "source_star_type",
        vector["star_type"],
        result["system"]["star_type_raw"],
    )

    predicted_by_slot = {
        int(row["slot"]): row for row in result["bodies"]
    }
    for expected in vector["bodies"]:
        slot = int(expected["slot"])
        actual = predicted_by_slot.get(slot)

        check(f"slot_{slot}_exists", True, actual is not None)
        if actual is None:
            continue

        check(
            f"slot_{slot}_seed",
            expected["planet_seed"].upper(),
            actual["planet_seed"].upper(),
        )
        check(
            f"slot_{slot}_planet_size",
            expected["planet_size"],
            actual["planet_size"],
        )
        check(
            f"slot_{slot}_class",
            expected["final_class"],
            actual["final_class"],
        )
        check(
            f"slot_{slot}_biome",
            expected["biome"],
            actual["biome"],
        )
        check(
            f"slot_{slot}_subtype",
            expected["biome_subtype"],
            actual["biome_subtype"],
        )

    return matches, checks, failures


def self_test(
    base: Path,
    tables: dict[str, Any],
    catalogs: dict[str, Any],
    vectors: dict[str, Any],
) -> list[str]:
    # Retain all original V2S controlled validation.
    lines = [
        "V2S_CONTROLLED_CORE=PASS",
        *v2s.self_test(tables, catalogs, vectors),
    ]

    # The two original systems have no pre-postprocess Biome-6 conversion.
    for portal in ("000000000000", "11680850FB82"):
        result = predict(portal, tables, catalogs, vectors)
        if any(row["force_continents"] for row in result["bodies"]):
            raise AssertionError(
                f"Unexpected ForceContinents conversion in {portal}."
            )

    vector = json.loads(
        (base / "blind_validation_v2t_vector.json").read_text(
            encoding="utf-8"
        )
    )
    blind = predict(vector["portal"], tables, catalogs, vectors)
    matches, checks, failures = compare_blind_vector(blind, vector)

    if failures:
        raise AssertionError("; ".join(failures))
    if (matches, checks) != (25, 25):
        raise AssertionError(
            f"Unexpected blind validation total {matches}/{checks}."
        )

    slot0 = blind["bodies"][0]
    trace = blind["force_continents_postprocess"]["trace"]
    if (
        slot0["biome"] != 7
        or slot0["biome_subtype"] != 5
        or slot0["force_continents"] is not True
        or not trace
        or trace[0]["roll_word"] != "0x27DEDEFF"
        or trace[0]["subtype_word"] != "0x444AF5ED"
        or trace[0]["uniform_catalog_index"] != 2
    ):
        raise AssertionError("Blind ForceContinents replay mismatch.")

    lines.extend(
        [
            "BLIND_SYSTEM=0123456789AB STATUS=PASS",
            "BLIND_CRITICAL_FIELDS_MATCHED=25/25",
            "BLIND_PLANET_SEEDS_MATCHED=3/3",
            "BLIND_PLANET_SIZES_MATCHED=3/3",
            "BLIND_FINAL_CLASSES_MATCHED=3/3",
            "BLIND_FINAL_BIOMES_MATCHED=3/3",
            "BLIND_FINAL_SUBTYPES_MATCHED=3/3",
            "BLIND_FORCE_CONTINENTS_FLAGS_MATCHED=3/3",
            "FORCE_CONTINENTS_SLOT0=PASS "
            "ROLL=0x27DEDEFF SUBTYPE_WORD=0x444AF5ED "
            "INDEX=2 FINAL=7/5",
            "ADDRESS_ONLY_FINAL_STANDARD_BRANCH_VALIDATED=True",
        ]
    )
    return lines


def format_report(result: dict[str, Any]) -> str:
    address = result["address"]
    system = result["system"]
    mode = result["class_mode"]
    structure = result["planet_structure"]
    budget = result["direct_rng_budget"]

    lines = [
        "FIBONACCI NMS ADDRESS-ONLY FINAL BIOME PREDICTOR V2V",
        f"Version={VERSION}",
        "Mode=OFFLINE_NO_NMS_PROCESS",
        "",
        "ADDRESS",
        "-------",
        f"input_portal={address['input_portal']}",
        f"resolved_system_portal={address['resolved_system_portal']}",
        f"tkseed={address['tkseed']}",
        f"ssi=0x{address['ssi']:03X}",
        f"voxel_x={address['voxel_x']}",
        f"voxel_y={address['voxel_y']}",
        f"voxel_z={address['voxel_z']}",
        "",
        "SYSTEM",
        "------",
        f"primary_count={system['primary_count']}",
        f"secondary_count={system['secondary_count']}",
        f"final_count={system['final_count']}",
        f"star_type_raw={system['star_type_raw']}",
        f"star_colour_confirmed={system['star_colour_confirmed']}",
        "",
        "CLASS + STRUCTURE",
        "-----------------",
        f"class_mode={mode['mode']}",
        "class_one_position_1_based="
        f"{mode['class_one_position_1_based']}",
        f"final_classes={result['final_classes']}",
        f"planet_sizes={structure['planet_sizes']}",
        f"biome_entry_offset={budget['biome_entry_offset']}",
        "",
        "FINAL PREDICTED PLANETS",
        "-----------------------",
    ]

    for body in result["bodies"]:
        lines.append(
            f"slot={body['slot']} "
            f"kind={body['kind']} "
            f"seed={body['planet_seed']} "
            f"PlanetSize={body['planet_size']} "
            f"Class={body['final_class']} "
            f"Biome={body['biome']} "
            f"BiomeSubType={body['biome_subtype']} "
            f"ForceContinents={body['force_continents']} "
            f"pre={body['pre_postprocess_biome']}/"
            f"{body['pre_postprocess_biome_subtype']}"
        )

    trace = result["force_continents_postprocess"]["trace"]
    lines.extend(["", "FORCE-CONTINENTS TRACE", "----------------------"])
    if not trace:
        lines.append("No pre-postprocess Biome-6 bodies.")
    else:
        for row in trace:
            lines.append(
                f"slot={row['slot']} "
                f"roll={row['roll_word']} "
                f"probability={row['roll_probability']} "
                f"convert={row['conversion']} "
                f"final={row['final_biome']}/{row['final_subtype']}"
            )
            if "subtype_word" in row:
                lines.append(
                    f"  subtype_word={row['subtype_word']} "
                    f"uniform_index={row['uniform_catalog_index']}"
                )

    lines.extend(
        [
            "",
            "VALIDITY",
            "--------",
            f"prediction_supported={result['prediction_supported']}",
            "standard_star_type_0_to_3=IMPLEMENTED",
            "force_continents_postprocess=IMPLEMENTED",
            "star_type_4_special_route=NOT_CLAIMED",
            "runtime_global_class_mode_3=NOT_CLAIMED",
        ]
    )
    for warning in result["warnings"]:
        lines.append(f"WARNING={warning}")

    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("portal", nargs="?")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    tables, catalogs, vectors = v2s.load_assets(base)

    if args.self_test:
        print("ADDRESS_ONLY_FINAL_BIOME_V2V_SELF_TEST=PASS")
        for line in self_test(base, tables, catalogs, vectors):
            print(line)
        return 0

    portal = args.portal or input(
        "Enter a 12-glyph portal address: "
    ).strip()
    result = predict(portal, tables, catalogs, vectors)

    output = (
        json.dumps(result, indent=2) + "\n"
        if args.json
        else format_report(result)
    )
    print(output, end="")

    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output, encoding="utf-8")
        print(f"REPORT={args.report}")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(3)
