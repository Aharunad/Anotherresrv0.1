#!/usr/bin/env python3
"""Portable exact English default procedural NMS planet-name generator."""
from __future__ import annotations

import argparse
import json
from typing import Any

from address_only_namegen_markov_v1 import (
    MWC,
    UNIT_U32,
    f32,
    generate_markov,
    high_multiply_u32,
)

ADORNMENTS = (
    'Prime', 'Major', 'Minor', 'Alpha', 'Beta',
    'Gamma', 'Delta', 'Omega', 'Sigma', 'Tau',
)

TEMPLATES = {
    1: '{norm}',
    2: '{norm} {adorn}',
    3: '{norm} {numeral}',
    4: '{norm} {shortcode}',
    5: '{long} {short}',
    6: '{short} {longcode}',
    7: '{norm}',
    8: '{norm} {adorn}',
    9: '{norm} {numeral}',
    10: 'New {norm}',
}

ROMAN = (
    '', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX',
    'X', 'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII',
    'XVIII', 'XIX', 'XX',
)


def _capitalise(word: str) -> str:
    return word[:1].upper() + word[1:]


def predict_planet_name(root_seed: int) -> dict[str, Any]:
    state = MWC(root_seed)

    adornment_index = high_multiply_u32(state.draw(), 10)
    short_code_number = 1 + high_multiply_u32(state.draw(), 50)
    short_code_letter = chr(ord('A') + high_multiply_u32(state.draw(), 26))
    numeral_number = 2 + high_multiply_u32(state.draw(), 18)
    long_code_last_number = 1 + high_multiply_u32(state.draw(), 9)
    long_code_letter = chr(ord('A') + high_multiply_u32(state.draw(), 26))
    long_code_first_number = 11 + high_multiply_u32(state.draw(), 89)

    proc_norm = _capitalise(generate_markov(state, 7, 4, 8))
    proc_short = _capitalise(generate_markov(state, 5, 4, 5))
    proc_long = _capitalise(generate_markov(state, 7, 6, 10))

    ordinary_style = 1 + high_multiply_u32(state.draw(), 9)
    style_10_probability = f32(state.draw() * UNIT_U32)
    style = 10 if style_10_probability < f32(0.035) else ordinary_style

    components = {
        'norm': proc_norm,
        'short': proc_short,
        'long': proc_long,
        'adorn': ADORNMENTS[adornment_index],
        'numeral': ROMAN[numeral_number],
        'shortcode': f'{short_code_letter}{short_code_number}',
        'longcode': (
            f'{long_code_first_number}/'
            f'{long_code_letter}{long_code_last_number}'
        ),
    }
    default_name = TEMPLATES[style].format(**components)

    return {
        'status': 'PASS_ADDRESS_ONLY_DEFAULT_PLANET_NAME_V1',
        'root_seed_hex': f'0x{root_seed & 0xFFFFFFFFFFFFFFFF:016X}',
        'default_procedural_name': default_name,
        'language': 'English',
        'style': style,
        'ordinary_style_before_override': ordinary_style,
        'style_10_probability_f32': style_10_probability,
        'style_10_threshold_f32': f32(0.035),
        'template': TEMPLATES[style],
        'components': components,
        'final_mwc_state': state.state_dict(),
        'scope_boundary': (
            'This predicts the default procedural name. Player renames and '
            'uploaded discovery-server names are not derivable from the seed.'
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('root_seed', help='64-bit planet root seed')
    args = parser.parse_args()
    print(json.dumps(predict_planet_name(int(args.root_seed, 0)), indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
