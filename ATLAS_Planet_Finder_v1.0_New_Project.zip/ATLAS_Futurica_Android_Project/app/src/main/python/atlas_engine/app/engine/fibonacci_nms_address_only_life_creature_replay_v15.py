#!/usr/bin/env python3
"""Exact current-build address-only Life and CreatureLife replay layer."""
from __future__ import annotations

import functools
import hashlib
import importlib.util
import json
import math
import re
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

VERSION = "1.0.45-standalone-life-creature-hardening"
HERE = Path(__file__).resolve().parent
APP_DIR = HERE.parent
DATA_DIR = APP_DIR / "data"
MODEL_DIR = DATA_DIR / "models"
CLEANROOM_DIR = HERE / "cleanroom"
SYSTEM_ENGINE_PATH = CLEANROOM_DIR / "fibonacci_nms_address_only_predictor_v2m.py"
SPECIAL_SYSTEM_VALIDATION_PATH = MODEL_DIR / "special_system_state_validation_v16c.json"
TABLE_PATH = DATA_DIR / "creature_generation_data_v11.bin"
TABLE_METADATA_PATH = DATA_DIR / "creature_generation_data_v11.json"
LIFE_REGRESSION_PATH = MODEL_DIR / "life_fauna_flora_regression_v1.json"
DESCRIPTOR_REGRESSION_PATH = MODEL_DIR / "creature_descriptor_regression_v1.json"
SYSTEM_REGRESSION_PATH = MODEL_DIR / "system_state_regression_v1.json"
EXPECTED_TABLE_SHA256 = "61ECEFEEE5F62C7876F0885F50B073EBE713DB0309A2B3B4740076D98E3738C9"

GALAXY_TYPE_TABLE = [
    4, 4, 2, 4, 4, 4, 1, 4, 4, 3,
    4, 1, 4, 4, 2, 4, 4, 4, 3, 4,
]
LEVEL_FAMILY = {
    0: "RARITY_NONE",
    1: "RARITY_LOW",
    2: "RARITY_MID",
    3: "RARITY_HIGH",
}
LEVEL_LABEL = {
    0: "None",
    1: "Low",
    2: "Medium",
    3: "High",
}
WEIRD_DESCRIPTOR_NAMES = {
    "WRDROLL",
    "WRDROLLPRED",
    "WRDCRYSTAL",
    "WRDCRYSTALPRED",
    "WRDFLOAT",
    "WRDBUTTERFLY",
    "PURPLEWEIRD",
    "GLOWSTRIDERS",
    "BEETLEWORLD",
    "PLANTCATWORLD",
}
MASK32 = 0xFFFFFFFF

_SYSTEM_ENGINE_MODULE = None


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def galaxy_type(galaxy_index: int) -> int:
    return int(GALAXY_TYPE_TABLE[int(galaxy_index) % len(GALAXY_TYPE_TABLE)])


def predict_life_level(
    *,
    biome: int,
    planet_class: int,
    galaxy_index: int,
) -> int:
    biome = int(biome)
    planet_class = int(planet_class)
    if biome in {6, 14, 15}:
        return 0
    if planet_class == 1:
        return 2 if galaxy_type(galaxy_index) == 1 else 3
    return 3


def predict_initial_creature_life(
    *,
    biome: int,
    planet_class: int,
    galaxy_index: int,
) -> int:
    biome = int(biome)
    planet_class = int(planet_class)
    if planet_class == 1:
        return 1 if galaxy_type(galaxy_index) == 1 else 2
    if biome in {6, 15}:
        return 0
    if biome == 14:
        return 3
    return 3


def _load_system_engine():
    global _SYSTEM_ENGINE_MODULE
    if _SYSTEM_ENGINE_MODULE is not None:
        return _SYSTEM_ENGINE_MODULE
    cleanroom_text = str(CLEANROOM_DIR.resolve())
    if cleanroom_text not in sys.path:
        sys.path.insert(0, cleanroom_text)
    spec = importlib.util.spec_from_file_location(
        "apf_standalone_system_generator_v2m",
        SYSTEM_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {SYSTEM_ENGINE_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _SYSTEM_ENGINE_MODULE = module
    return module


@functools.lru_cache(maxsize=8192)
def predict_system_state(portal: str, galaxy_index: int = 0) -> dict[str, Any]:
    canonical = "0" + str(portal).strip().upper()[1:]
    galaxy_index = int(galaxy_index)
    if not 0 <= galaxy_index <= 255:
        raise ValueError("Galaxy index must be 0..255.")
    engine = _load_system_engine()
    prediction = engine.predict_address(canonical, galaxy_index)
    decoded = prediction["decoded"]
    system = prediction["system"]
    scalars = {
        "decoded_field_230": int(system["decoded_field_230"]),
        "decoded_field_234": int(system["decoded_field_234"]),
        "decoded_field_23C": int(system["decoded_field_23C"]),
        "levelone_source": int(system["source_system_kind"]),
        "weather_class": int(system["star_type_raw"]),
        "internal_field_14": int(system["internal_class_limit"]),
        "classification_source": 0,
        "classification_mode": 0,
        "primary_count": int(system["primary_count"]),
        "derived_source_flag": int(system["internal_class_limit"]),
        "flag_250": int(bool(system["in_abandoned_system"])),
        "flag_253": int(bool(system["in_pirate_system"])),
        "secondary_count": int(system["secondary_count"]),
        "flag_252": int(bool(system["raw2c_auxiliary_flag"])),
        "weather_suppression": int(bool(system["in_gas_giant_system"])),
        "derived_boolean": int(
            int(system["star_type_raw"]) == 0
            and int(system["internal_class_limit"]) != 0
        ),
        "valid_flag": 1,
    }
    return {
        "canonical_system_portal": canonical,
        "galaxy_index": galaxy_index,
        "galaxy_seed_applied": True,
        "source_system_kind": int(system["source_system_kind"]),
        "in_empty_system": bool(system["in_empty_system"]),
        "in_abandoned_system": bool(system["in_abandoned_system"]),
        "in_gas_giant_system": bool(system["in_gas_giant_system"]),
        "in_pirate_system": bool(system["in_pirate_system"]),
        "in_gas_giant_system_candidate": bool(system["in_gas_giant_system"]),
        "in_pirate_system_candidate": bool(system["in_pirate_system"]),
        "unmapped_system_flag_252": bool(system["raw2c_auxiliary_flag"]),
        "candidate_scalars": scalars,
        "packed_input": f"0x{int(decoded['tkseed']):016X}",
        "normalized_packed": f"0x{int(decoded['tkseed']):016X}",
        "parsed_address": {
            "portal_planet_index": int(decoded["planet_glyph"]),
            "solar_system_index": int(decoded["supplied_ssi"]),
            "portal_y": int(decoded["raw_y"]),
            "portal_z": int(decoded["raw_z"]),
            "portal_x": int(decoded["raw_x"]),
        },
        "system_state_status": (
            "PASS_STANDALONE_SPECIAL_SYSTEM_REPLAY_EXACT"
        ),
    }


@dataclass
class WeightedList:
    descriptor_offset: int
    entries: list[tuple[str, float]]


class CreatureTable:
    def __init__(self) -> None:
        metadata = load_json(TABLE_METADATA_PATH)
        self.data = TABLE_PATH.read_bytes()
        self.captured_base = int(str(metadata["captured_base"]), 0)

    def weighted_list(self, descriptor_offset: int) -> WeightedList:
        pointer, count, _flags = struct.unpack_from(
            "<QII",
            self.data,
            descriptor_offset,
        )
        if int(count) == 0:
            return WeightedList(descriptor_offset, [])
        relative = int(pointer) - self.captured_base
        if relative < 0:
            raise RuntimeError(
                f"Invalid list descriptor at 0x{descriptor_offset:X}"
            )
        end = relative + int(count) * 0x18
        if end > len(self.data):
            raise RuntimeError(
                f"List at 0x{descriptor_offset:X} exceeds table"
            )
        entries = []
        for index in range(int(count)):
            offset = relative + index * 0x18
            name = self.data[
                offset:offset + 0x10
            ].split(b"\0", 1)[0].decode("ascii")
            weight = struct.unpack_from("<f", self.data, offset + 0x10)[0]
            entries.append((name, float(weight)))
        return WeightedList(descriptor_offset, entries)

    def context(self, offset: int) -> dict[str, Any]:
        return {
            "offset": offset,
            "aux_1": self.weighted_list(offset + 0x00),
            "aux_3": self.weighted_list(offset + 0x10),
            "primary": self.weighted_list(offset + 0x20),
            "aux_2": self.weighted_list(offset + 0x30),
            "threshold": struct.unpack_from(
                "<f", self.data, offset + 0x40
            )[0],
            "empty_fill": bool(self.data[offset + 0x44]),
        }


@functools.lru_cache(maxsize=1)
def creature_table() -> CreatureTable:
    return CreatureTable()


def push_child(core_api, parent, label: str):
    first = int(parent.draw())
    second = int(parent.draw())
    combined = ((second & MASK32) << 32) | (first & MASK32)
    seed = int(core_api.avalanche_mix_64(combined))
    return core_api.state_direct_64(seed), {
        "label": label,
        "parent_word_1": first,
        "parent_word_2": second,
        "combined_hex": f"0x{combined:016X}",
        "child_seed_hex": f"0x{seed:016X}",
    }


def weighted_select(
    core_api,
    parent,
    weighted: WeightedList,
    *,
    default: str,
    label: str,
):
    child, push_trace = push_child(core_api, parent, label)
    total = f32(0.0)
    for _name, weight in weighted.entries:
        total = f32(total + f32(weight))
    word = int(child.draw())
    unit = float(core_api.word_to_native_f32(word))
    target = f32(f32(unit) * total)
    remaining = target
    selected = default
    selected_index = None
    for index, (name, weight) in enumerate(weighted.entries):
        remaining = f32(remaining - f32(weight))
        if 0.0 >= remaining:
            selected = name
            selected_index = index
            break
    return selected, {
        **push_trace,
        "list_descriptor_offset": f"0x{weighted.descriptor_offset:X}",
        "selector_word": word,
        "selector_unit_f32": unit,
        "selected_index": selected_index,
        "selected_descriptor": selected,
    }


def context_helper(
    core_api,
    parent,
    *,
    context_offset: int,
    fields: dict[str, str | None],
    biome: int,
    sea_level: float,
    flag_302c: int,
    flag_306c: int,
    label: str,
) -> dict[str, Any]:
    context = creature_table().context(context_offset)
    child, trace = push_child(core_api, parent, label)
    threshold_word = int(child.draw())
    threshold_unit = float(core_api.word_to_native_f32(threshold_word))
    passed = threshold_unit <= float(context["threshold"])
    trace.update(
        {
            "context_offset": f"0x{context_offset:X}",
            "threshold_word": threshold_word,
            "threshold_unit_f32": threshold_unit,
            "threshold_f32": float(context["threshold"]),
            "passed": passed,
            "weighted_selections": [],
        }
    )
    if not passed:
        return trace

    if int(biome) != 14:
        fields["primary"], selection = weighted_select(
            core_api,
            child,
            context["primary"],
            default="EMPTY",
            label=f"{label}.primary",
        )
        trace["weighted_selections"].append(selection)

    if float(sea_level) > 0.0 and float(sea_level) >= 120.0:
        fields["aux_2"], selection = weighted_select(
            core_api,
            child,
            context["aux_2"],
            default="EMPTY",
            label=f"{label}.aux_2",
        )
        trace["weighted_selections"].append(selection)

    fields["aux_1"], selection = weighted_select(
        core_api,
        child,
        context["aux_1"],
        default="EMPTY",
        label=f"{label}.aux_1",
    )
    trace["weighted_selections"].append(selection)

    if int(flag_302c) or int(flag_306c):
        fields["aux_3"], selection = weighted_select(
            core_api,
            child,
            context["aux_3"],
            default="EMPTY",
            label=f"{label}.aux_3",
        )
        trace["weighted_selections"].append(selection)

    if context["empty_fill"]:
        for key in fields:
            if fields[key] is None:
                fields[key] = "EMPTY"
    return trace


def descriptor_local_state(core_api, root_seed: int):
    children = core_api.generate_children(int(root_seed))
    child_11_seed = int(children[10])
    state = core_api.state_direct_64(child_11_seed)
    word_1 = int(state.draw())
    word_2 = int(state.draw())
    combined = ((word_2 & MASK32) << 32) | (word_1 & MASK32)
    local_seed = int(core_api.avalanche_mix_64(combined))
    return core_api.state_direct_64(local_seed), {
        "child_11_seed_hex": f"0x{child_11_seed:016X}",
        "descriptor_local_seed_hex": f"0x{local_seed:016X}",
    }


def infer_special_fauna(primary: str, biome: int) -> tuple[bool, str]:
    if primary == "ROBOT":
        return True, "robot"
    if int(biome) == 7 and (
        primary.startswith("WRD")
        or primary in WEIRD_DESCRIPTOR_NAMES
    ):
        return True, "weird"
    return False, "standard"


def abundance_token(
    core_api,
    *,
    root_seed: int,
    level: int,
    draw: int,
    special_kind: str = "standard",
) -> dict[str, Any]:
    word = int(core_api.stream_words(int(root_seed), 22, draw)[draw - 1])
    if special_kind == "robot":
        return {
            "family": "RARITY_ROBOT",
            "token": "RARITY_ROBOT1",
            "suffix": 1,
            "selector_word": word,
            "selector_count": 1,
        }
    if special_kind == "weird":
        count = 8
        family = "RARITY_WEIRD"
    else:
        count = 10
        family = LEVEL_FAMILY[int(level)]
    suffix = int(core_api.select_mulhi(word, count)) + 1
    return {
        "family": family,
        "token": f"{family}{suffix}",
        "suffix": suffix,
        "selector_word": word,
        "selector_count": count,
    }


def emulate_descriptors(
    core_api,
    *,
    root_seed: int,
    biome: int,
    biome_subtype: int,
    planet_class: int,
    star_type: int,
    sea_level: float,
    flag_302c: int,
    flag_306c: int,
    galaxy_index: int,
    system_state: dict[str, Any],
) -> dict[str, Any]:
    initial = predict_initial_creature_life(
        biome=biome,
        planet_class=planet_class,
        galaxy_index=galaxy_index,
    )

    # Native class-1 path at 0x16F67D5.
    if int(planet_class) == 1:
        fields = {
            "primary": "DEFAULT",
            "aux_1": "DEFAULT",
            "aux_2": "DEFAULT" if float(sea_level) > 0.0 else "EMPTY",
            "aux_3": (
                "DEFAULT"
                if int(flag_302c) or int(flag_306c)
                else "EMPTY"
            ),
        }
        return {
            "initial_creature_life": initial,
            "creature_life": initial,
            "descriptors": fields,
            "context_helpers": [],
            "descriptor_branch": "native_class_1_static_branch",
        }

    root_state, lineage = descriptor_local_state(core_api, int(root_seed))
    _prelude, prelude_trace = push_child(core_api, root_state, "prelude")
    _prelude.draw()
    _prelude.draw()
    descriptor_parent, parent_trace = push_child(
        core_api, root_state, "descriptor_parent"
    )

    fields: dict[str, str | None] = {
        "primary": None,
        "aux_1": None,
        "aux_2": None,
        "aux_3": None,
    }
    helpers = []

    if initial == 0:
        for key in fields:
            fields[key] = "EMPTY"
    else:
        if bool(system_state.get("in_empty_system")):
            helpers.append(
                context_helper(
                    core_api,
                    descriptor_parent,
                    context_offset=0xE10,
                    fields=fields,
                    biome=biome,
                    sea_level=sea_level,
                    flag_302c=flag_302c,
                    flag_306c=flag_306c,
                    label="in_empty_system_E10",
                )
            )
        elif int(star_type) == 4:
            helpers.append(
                context_helper(
                    core_api,
                    descriptor_parent,
                    context_offset=0xE58,
                    fields=fields,
                    biome=biome,
                    sea_level=sea_level,
                    flag_302c=flag_302c,
                    flag_306c=flag_306c,
                    label="purple_star_E58",
                )
            )
        elif bool(system_state.get("in_abandoned_system")):
            helpers.append(
                context_helper(
                    core_api,
                    descriptor_parent,
                    context_offset=0xDC8,
                    fields=fields,
                    biome=biome,
                    sea_level=sea_level,
                    flag_302c=flag_302c,
                    flag_306c=flag_306c,
                    label="abandoned_system_DC8",
                )
            )

        if fields["primary"] is None and int(biome) == 7:
            helpers.append(
                context_helper(
                    core_api,
                    descriptor_parent,
                    context_offset=int(biome_subtype) * 0x48,
                    fields=fields,
                    biome=biome,
                    sea_level=sea_level,
                    flag_302c=flag_302c,
                    flag_306c=flag_306c,
                    label="weird_subtype_context",
                )
            )

    _noise, noise_trace = push_child(
        core_api, descriptor_parent, "noise_stage"
    )

    if int(biome) == 14:
        fields["primary"] = "EMPTY"
        fields["aux_3"] = "EMPTY"

    fallback_parent, fallback_trace = push_child(
        core_api, descriptor_parent, "fallback_parent"
    )
    fallback = []

    if fields["primary"] is None:
        fields["primary"], trace = weighted_select(
            core_api,
            fallback_parent,
            creature_table().weighted_list(0xEC0),
            default="DEFAULT",
            label="fallback.primary",
        )
        fallback.append(trace)

    if fields["aux_1"] is None:
        list_offset = (
            0xEE0 if fields["primary"] == "EMPTY" else 0xEA0
        )
        fields["aux_1"], trace = weighted_select(
            core_api,
            fallback_parent,
            creature_table().weighted_list(list_offset),
            default="DEFAULT",
            label="fallback.aux_1",
        )
        fallback.append(trace)

    if (
        fields["aux_2"] is None
        and float(sea_level) > 0.0
        and float(sea_level) >= 120.0
    ):
        fields["aux_2"], trace = weighted_select(
            core_api,
            fallback_parent,
            creature_table().weighted_list(0xED0),
            default="DEFAULT",
            label="fallback.aux_2",
        )
        fallback.append(trace)

    if fields["aux_3"] is None and (
        int(flag_302c) or int(flag_306c)
    ):
        fields["aux_3"], trace = weighted_select(
            core_api,
            fallback_parent,
            creature_table().weighted_list(0xEB0),
            default="DEFAULT",
            label="fallback.aux_3",
        )
        fallback.append(trace)

    final_fields = {
        key: value if value is not None else "EMPTY"
        for key, value in fields.items()
    }

    final_creature = initial
    if final_fields["primary"] == "EMPTY" and int(biome) != 14:
        final_creature = (
            1
            if any(
                final_fields[key] != "EMPTY"
                for key in ("aux_1", "aux_2", "aux_3")
            )
            else 0
        )

    return {
        "initial_creature_life": initial,
        "creature_life": final_creature,
        "descriptors": final_fields,
        "context_helpers": helpers,
        "fallback_selectors": fallback,
        "seed_lineage": lineage,
        "prelude": prelude_trace,
        "descriptor_parent": parent_trace,
        "noise_stage": noise_trace,
        "fallback_parent": fallback_trace,
        "descriptor_branch": "native_v13_address_only_emulator",
    }


def predict_planet(
    core_api,
    row: dict[str, Any],
    *,
    system_state: dict[str, Any],
    galaxy_index: int,
    flag_302c: int = 1,
    flag_306c: int = 1,
) -> dict[str, Any]:
    seed_text = str(row.get("planet_seed_hex", row.get("root_seed_hex", "")))
    root_seed = int(seed_text, 0)
    biome = int(row["biome"])
    planet_class = int(row["planet_class"])
    star_type = int(row["star_type"])
    sea_level = float(row.get("sea_level", 0.0))

    life_level = predict_life_level(
        biome=biome,
        planet_class=planet_class,
        galaxy_index=galaxy_index,
    )
    descriptor = emulate_descriptors(
        core_api,
        root_seed=root_seed,
        biome=biome,
        biome_subtype=int(row["biome_subtype"]),
        planet_class=planet_class,
        star_type=star_type,
        sea_level=sea_level,
        flag_302c=int(flag_302c),
        flag_306c=int(flag_306c),
        galaxy_index=galaxy_index,
        system_state=system_state,
    )
    creature_level = int(descriptor["creature_life"])
    primary = descriptor["descriptors"]["primary"]
    special, special_kind = infer_special_fauna(primary, biome)

    # Weird/Exotic worlds use the dedicated RARITY_WEIRD discovery-text
    # family for flora as well as fauna. v1.0.44 incorrectly routed flora
    # through the ordinary level family, producing values such as Abundant
    # instead of Between Worlds / Lost.
    flora = abundance_token(
        core_api,
        root_seed=root_seed,
        level=life_level,
        draw=4,
        special_kind=("weird" if biome == 7 else "standard"),
    )
    fauna = abundance_token(
        core_api,
        root_seed=root_seed,
        level=creature_level,
        draw=5,
        special_kind=special_kind,
    )

    return {
        "life_level": life_level,
        "flora_level": life_level,
        "flora_abundance": LEVEL_LABEL[life_level],
        "flora_family": flora["family"],
        "flora_token": flora["token"],
        "flora_token_suffix": flora["suffix"],
        "flora_selector_child_22_draw_4": flora["selector_word"],
        "creature_life_level": creature_level,
        "fauna_level": creature_level,
        "fauna_abundance": LEVEL_LABEL[creature_level],
        "fauna_family": fauna["family"],
        "fauna_token": fauna["token"],
        "fauna_token_suffix": fauna["suffix"],
        "fauna_selector_child_22_draw_5": fauna["selector_word"],
        "special_fauna_predicted": special,
        "special_fauna_kind": special_kind,
        "creature_descriptor_primary": primary,
        "creature_descriptor_aux_1": descriptor["descriptors"]["aux_1"],
        "creature_descriptor_aux_2": descriptor["descriptors"]["aux_2"],
        "creature_descriptor_aux_3": descriptor["descriptors"]["aux_3"],
        "creature_descriptor_branch": descriptor["descriptor_branch"],
        "creature_descriptor_flag_302c": int(flag_302c),
        "creature_descriptor_flag_306c": int(flag_306c),
        "life_prediction_status": (
            "validated_native_writer_71_planets_current_build"
        ),
        "creature_life_prediction_status": (
            "validated_v13_v14_address_only_current_build"
        ),
        "fauna_flora_token_status": (
            "validated_child22_draw4_draw5_selector_schedule"
        ),
    }


def enrich_planet(
    core_api,
    row: dict[str, Any],
    *,
    system_state: dict[str, Any],
    galaxy_index: int,
) -> dict[str, Any]:
    output = dict(row)
    output.update(
        predict_planet(
            core_api,
            row,
            system_state=system_state,
            galaxy_index=galaxy_index,
        )
    )
    output.update(
        {
            "source_system_kind": system_state["source_system_kind"],
            "in_empty_system": system_state["in_empty_system"],
            "in_abandoned_system": system_state["in_abandoned_system"],
            "in_gas_giant_system": system_state["in_gas_giant_system"],
            "in_pirate_system": system_state["in_pirate_system"],
        }
    )
    return output


def verify_static() -> dict[str, Any]:
    system_engine = _load_system_engine()
    validation = load_json(SPECIAL_SYSTEM_VALIDATION_PATH)
    rows = validation["v16a_corpus_classification"]["rows"]
    fields = (
        "source_system_kind",
        "in_abandoned_system",
        "in_empty_system",
        "in_gas_giant_system",
        "in_pirate_system",
        "raw2c_auxiliary_flag",
    )
    exact_rows = 0
    for row in rows:
        predicted = system_engine.predict_address(row["portal"])["system"]
        if all(predicted[field] == row[field] for field in fields):
            exact_rows += 1
    checks = {
        "standalone_system_engine_loads": bool(system_engine),
        "creature_table_sha256": (
            sha256_file(TABLE_PATH) == EXPECTED_TABLE_SHA256
        ),
        "special_system_corpus_349_of_349": (
            len(rows) == 349 and exact_rows == 349
        ),
        "no_game_runtime_required": True,
    }
    return {
        "checks": checks,
        "special_system_rows_exact": exact_rows,
        "special_system_rows_total": len(rows),
        "exact": all(checks.values()),
    }


def _metric(correct: int, total: int) -> dict[str, Any]:
    return {
        "correct": int(correct),
        "total": int(total),
        "exact": bool(total > 0 and correct == total),
    }


def run_pure_regression(core_api) -> dict[str, Any]:
    life_data = load_json(LIFE_REGRESSION_PATH)
    descriptor_data = load_json(DESCRIPTOR_REGRESSION_PATH)
    static = verify_static()

    counts = {
        "life_numeric": [0, 0],
        "flora_token": [0, 0],
        "fauna_standard_token": [0, 0],
        "fauna_weird_token": [0, 0],
        "fauna_robot_token": [0, 0],
        "descriptor_primary": [0, 0],
        "descriptor_aux_1": [0, 0],
        "descriptor_aux_2": [0, 0],
        "descriptor_aux_3": [0, 0],
        "creature_life": [0, 0],
    }
    failures = []

    token_pattern = re.compile(
        r"RARITY_(?:NONE|LOW|MID|HIGH)\d+$"
    )

    for row in life_data["rows"]:
        predicted_life = predict_life_level(
            biome=row["biome"],
            planet_class=row["planet_class"],
            galaxy_index=0,
        )
        counts["life_numeric"][1] += 1
        counts["life_numeric"][0] += int(
            predicted_life == int(row["life"])
        )

        root_seed = int(row["root_seed_hex"], 0)
        flora = abundance_token(
            core_api,
            root_seed=root_seed,
            level=predicted_life,
            draw=4,
        )
        if token_pattern.fullmatch(str(row["flora_text"])):
            counts["flora_token"][1] += 1
            counts["flora_token"][0] += int(
                flora["token"] == row["flora_text"]
            )

        if row["special_fauna"]:
            if int(row["biome"]) == 7:
                fauna = abundance_token(
                    core_api,
                    root_seed=root_seed,
                    level=row["creature_life"],
                    draw=5,
                    special_kind="weird",
                )
                key = "fauna_weird_token"
            else:
                fauna = abundance_token(
                    core_api,
                    root_seed=root_seed,
                    level=row["creature_life"],
                    draw=5,
                    special_kind="robot",
                )
                key = "fauna_robot_token"
            counts[key][1] += 1
            counts[key][0] += int(
                fauna["token"] == row["fauna_text"]
            )
        elif token_pattern.fullmatch(str(row["fauna_text"])):
            fauna = abundance_token(
                core_api,
                root_seed=root_seed,
                level=row["creature_life"],
                draw=5,
            )
            counts["fauna_standard_token"][1] += 1
            counts["fauna_standard_token"][0] += int(
                fauna["token"] == row["fauna_text"]
            )

    for row in descriptor_data["rows"]:
        state = {
            "in_empty_system": bool(row["in_empty_system"]),
            "in_abandoned_system": bool(row["in_abandoned_system"]),
        }
        predicted = emulate_descriptors(
            core_api,
            root_seed=int(row["root_seed_hex"], 0),
            biome=int(row["biome"]),
            biome_subtype=int(row["biome_subtype"]),
            planet_class=int(row["planet_class"]),
            star_type=int(row["star_type"]),
            sea_level=float(row["sea_level"]),
            flag_302c=int(row["flag_302c"]),
            flag_306c=int(row["flag_306c"]),
            galaxy_index=0,
            system_state=state,
        )
        for key, metric_key in (
            ("primary", "descriptor_primary"),
            ("aux_1", "descriptor_aux_1"),
            ("aux_2", "descriptor_aux_2"),
            ("aux_3", "descriptor_aux_3"),
        ):
            counts[metric_key][1] += 1
            counts[metric_key][0] += int(
                predicted["descriptors"][key]
                == row["expected_descriptors"][key]
            )
        counts["creature_life"][1] += 1
        counts["creature_life"][0] += int(
            predicted["creature_life"]
            == int(row["expected_creature_life"])
        )

    metrics = {
        name: _metric(correct, total)
        for name, (correct, total) in counts.items()
    }
    metrics["life_creature_static"] = _metric(
        sum(static["checks"].values()),
        len(static["checks"]),
    )
    exact = all(item["exact"] for item in metrics.values())
    return {
        "status": (
            "PASS_LIFE_CREATURE_PURE_REGRESSION_EXACT"
            if exact
            else "ERROR_LIFE_CREATURE_PURE_REGRESSION"
        ),
        "exact": exact,
        "metrics": metrics,
        "static": static,
        "failures": failures,
    }


def run_full_regression(core_api) -> dict[str, Any]:
    pure = run_pure_regression(core_api)
    system_data = load_json(SYSTEM_REGRESSION_PATH)
    descriptor_data = load_json(DESCRIPTOR_REGRESSION_PATH)

    source_correct = source_total = 0
    empty_correct = empty_total = 0
    failures = []

    for row in system_data["rows"]:
        actual = predict_system_state(row["portal"])
        expected_kind = row["expected_source_system_kind"]
        if expected_kind is not None:
            source_total += 1
            source_correct += int(
                int(actual["source_system_kind"])
                == int(expected_kind)
            )
        empty_total += 1
        empty_correct += int(
            bool(actual["in_empty_system"])
            == bool(row["expected_in_empty_system"])
        )

    address_descriptor = {
        "descriptor_primary": [0, 0],
        "descriptor_aux_1": [0, 0],
        "descriptor_aux_2": [0, 0],
        "descriptor_aux_3": [0, 0],
        "creature_life": [0, 0],
    }
    for row in descriptor_data["rows"]:
        state = predict_system_state(row["system_portal"])
        predicted = emulate_descriptors(
            core_api,
            root_seed=int(row["root_seed_hex"], 0),
            biome=int(row["biome"]),
            biome_subtype=int(row["biome_subtype"]),
            planet_class=int(row["planet_class"]),
            star_type=int(row["star_type"]),
            sea_level=float(row["sea_level"]),
            flag_302c=int(row["flag_302c"]),
            flag_306c=int(row["flag_306c"]),
            galaxy_index=0,
            system_state=state,
        )
        for key, metric_key in (
            ("primary", "descriptor_primary"),
            ("aux_1", "descriptor_aux_1"),
            ("aux_2", "descriptor_aux_2"),
            ("aux_3", "descriptor_aux_3"),
        ):
            address_descriptor[metric_key][1] += 1
            address_descriptor[metric_key][0] += int(
                predicted["descriptors"][key]
                == row["expected_descriptors"][key]
            )
        address_descriptor["creature_life"][1] += 1
        address_descriptor["creature_life"][0] += int(
            predicted["creature_life"]
            == int(row["expected_creature_life"])
        )

    metrics = dict(pure["metrics"])
    metrics["source_system_kind"] = _metric(
        source_correct, source_total
    )
    metrics["in_empty_system"] = _metric(
        empty_correct, empty_total
    )
    for name, (correct, total) in address_descriptor.items():
        metrics[f"address_{name}"] = _metric(correct, total)

    exact = all(metric["exact"] for metric in metrics.values())
    return {
        "status": (
            "PASS_LIFE_CREATURE_FULL_REGRESSION_EXACT"
            if exact
            else "ERROR_LIFE_CREATURE_FULL_REGRESSION"
        ),
        "exact": exact,
        "metrics": metrics,
        "pure": pure,
        "failures": failures,
    }
