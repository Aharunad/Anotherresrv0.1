#!/usr/bin/env python3
"""Exact address-only RNG schedule for NMS planet water profiles.

Current-build closure:
- one-of-19 WATERCOLOURS style index;
- WaterEmission selector word and native float32 unit;
- FoamEmission selector word and native float32 unit;
- Murkyness, bit-for-bit float32 exact.

The final WaterEmission/FoamEmission enum requires the current
GcWaterColourSettingList emission-weight matrix. Use ``select_weighted_enum``
with the recovered four weights once that matrix is available.
"""
from __future__ import annotations

import argparse
import json
import struct
from typing import Any, Sequence

VERSION = "1.1.0"
TAG = "atlas_apf_address_only_water_profile_rng_v1"

MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899
AVALANCHE_MULTIPLIER_1 = 0x64DD81482CBD31D7
AVALANCHE_MULTIPLIER_2 = 0xE36AA5C613612997
NORM_U32 = 1.0 / 4294967296.0
EMISSION_ENUM_NAMES = ("None", "Constant", "Pulse", "NightOnly")


def f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def f32_bits(value: float) -> int:
    return struct.unpack("<I", struct.pack("<f", f32(value)))[0]


def rotate_right_32(value: int, count: int) -> int:
    value &= MASK32
    count &= 31
    if not count:
        return value
    return ((value >> count) | (value << (32 - count))) & MASK32


def avalanche_mix_64(value: int) -> int:
    value &= MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_1) & MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_2) & MASK64
    value ^= value >> 33
    return value & MASK64


class MWC:
    __slots__ = ("value", "carry")

    def __init__(self, value: int, carry: int) -> None:
        self.value = value & MASK32
        self.carry = carry & MASK32

    @classmethod
    def direct_seed64(cls, seed: int) -> "MWC":
        seed &= MASK64
        low = seed & MASK32
        high = (seed >> 32) & MASK32
        if low == 0:
            low = 1
        carry = (rotate_right_32(low, 16) ^ high ^ low) & MASK32
        return cls(low, carry)

    def draw(self) -> int:
        total = MWC_MULTIPLIER * self.value + self.carry
        self.value = total & MASK32
        self.carry = (total >> 32) & MASK32
        return self.value


def child_seed_ordinal(root_seed: int, ordinal: int) -> int:
    if ordinal < 1:
        raise ValueError("ordinal must be >= 1")
    state = MWC.direct_seed64(root_seed)
    child = 0
    for _ in range(ordinal):
        low = state.draw()
        high = state.draw()
        child = avalanche_mix_64(((high & MASK32) << 32) | (low & MASK32))
    return child


def word_to_unit_f32(word: int) -> float:
    # Native path converts the zero-extended u32 to double, multiplies by
    # 2^-32, then converts to float32.
    return f32((word & MASK32) * NORM_U32)


def select_weighted_enum(word: int, weights: Sequence[float]) -> dict[str, Any]:
    """Replay the native four-way emission selector.

    The native emission path uses float32 sums, a zero epsilon, and a strict
    cumulative ``> target`` comparison. If all weights are zero, output remains
    the constructor default enum 0 (None).
    """
    if len(weights) != 4:
        raise ValueError("emission weights must contain exactly four values")
    normalised = [f32(value) for value in weights]
    if any(value < 0.0 for value in normalised):
        raise ValueError("emission weights must not be negative")
    total = f32(0.0)
    for value in normalised:
        total = f32(total + value)
    unit = word_to_unit_f32(word)
    target = f32(unit * total)
    selected = 0
    if total >= 0.0:
        cumulative = f32(0.0)
        for index, value in enumerate(normalised):
            cumulative = f32(cumulative + value)
            if cumulative > target:
                selected = index
                break
    return {
        "selector_word": word & MASK32,
        "selector_unit_f32": unit,
        "weights_f32": normalised,
        "total_f32": total,
        "target_f32": target,
        "enum": selected,
        "enum_name": EMISSION_ENUM_NAMES[selected],
    }


def predict_from_root_seed(root_seed: int) -> dict[str, Any]:
    root_seed &= MASK64
    child18 = child_seed_ordinal(root_seed, 18)
    context = MWC.direct_seed64(child18)
    context_word_1 = context.draw()
    context_word_2 = context.draw()
    water_local_seed = avalanche_mix_64(
        ((context_word_2 & MASK32) << 32) | (context_word_1 & MASK32)
    )
    style_selector_word = context.draw()

    local = MWC.direct_seed64(water_local_seed)
    local_word_1 = local.draw()
    local_word_2 = local.draw()
    emission_seed = avalanche_mix_64(
        ((local_word_2 & MASK32) << 32) | (local_word_1 & MASK32)
    )
    emission = MWC.direct_seed64(emission_seed)
    water_selector_word = emission.draw()
    foam_selector_word = emission.draw()

    local_word_3 = local.draw()
    local_word_4 = local.draw()
    murkyness_seed = avalanche_mix_64(
        ((local_word_4 & MASK32) << 32) | (local_word_3 & MASK32)
    )
    murkyness_state = MWC.direct_seed64(murkyness_seed)
    murkyness_selector_word = murkyness_state.draw()
    murkyness_unit = word_to_unit_f32(murkyness_selector_word)

    # Native curve helper ID 0x16 is x^5. Preserve each SSE float32
    # multiplication/rounding step.
    x = murkyness_unit
    x2 = f32(x * x)
    x3 = f32(x2 * x)
    x4 = f32(x3 * x)
    murkyness = f32(x * x4)

    return {
        "status": "PASS_ADDRESS_ONLY_WATER_PROFILE_RNG_V1",
        "root_seed_hex": f"0x{root_seed:016X}",
        "child_seed_18_hex": f"0x{child18:016X}",
        "context_words": [
            context_word_1,
            context_word_2,
            style_selector_word,
        ],
        "water_local_seed_hex": f"0x{water_local_seed:016X}",
        "water_local_words": [
            local_word_1,
            local_word_2,
            local_word_3,
            local_word_4,
        ],
        "style_selector_word": style_selector_word,
        "emission_seed_hex": f"0x{emission_seed:016X}",
        "water_emission_selector_word": water_selector_word,
        "water_emission_selector_unit_f32": word_to_unit_f32(
            water_selector_word
        ),
        "foam_emission_selector_word": foam_selector_word,
        "foam_emission_selector_unit_f32": word_to_unit_f32(
            foam_selector_word
        ),
        "murkyness_seed_hex": f"0x{murkyness_seed:016X}",
        "murkyness_selector_word": murkyness_selector_word,
        "murkyness_selector_unit_f32": murkyness_unit,
        "murkyness_f32": murkyness,
        "murkyness_bits_hex": f"0x{f32_bits(murkyness):08X}",
        "claim_boundary": {
            "style_selector_word_exact": True,
            "water_emission_selector_word_exact": True,
            "foam_emission_selector_word_exact": True,
            "murkyness_bit_exact": True,
            "emission_enum_requires_weight_matrix": True,
        },
    }


# Backward-compatible short name used in early research scripts.
def predict(root_seed: int) -> dict[str, Any]:
    return predict_from_root_seed(root_seed)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root_seed", help="64-bit root seed, decimal or 0x...")
    args = parser.parse_args()
    print(json.dumps(predict_from_root_seed(int(args.root_seed, 0)), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
