#!/usr/bin/env python3
"""
FIBONACCI NMS ADDRESS-ONLY SYSTEM + PLANET-SEED PREDICTOR V2M

This is an entirely offline clean-room port of the current No Man's Sky
6.45 default system-generation route identified in the uploaded executable
memory image.

No NMS process is opened. Nothing is written to the game, saves, MODS,
settings, or executable.

Implemented from a 12-glyph address alone
-----------------------------------------
* resolved packed system address / TkSeed
* Threefry4x64-20 counter and selected 32-bit generator word
* primary-body count
* secondary-body count
* final body count
* raw StarType
* exact per-body 64-bit generation seeds
* source PlanetSize values and RNG draw trace

Not implemented yet
-------------------
* planet seed -> Biome / BiomeSubType
* full weather, sentinel, water, resource, flora/fauna details
* confirmed display names for raw StarType values 2, 3, and 4
* every possible external runtime override used by rare special branches

The two captured systems are strict self-test vectors. Counts, StarType,
classes, and all six active seeds must match exactly.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import struct
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import fibonacci_nms_candidate_array_replay as candidate_arrays

VERSION = "2M.0.0"

MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF

THREEFRY_C240 = 0x1BD11BDAA9FC1A22
THREEFRY_ROTATIONS = (
    (14, 16),
    (52, 57),
    (23, 40),
    (5, 37),
    (25, 33),
    (46, 12),
    (58, 22),
    (32, 32),
)

MWC_MULTIPLIER = 0x5A76F899
AVALANCHE_MULTIPLIER_1 = 0x64DD81482CBD31D7
AVALANCHE_MULTIPLIER_2 = 0xE36AA5C613612997

BASE_SYSTEM_INDEX_CUTOFF = 120
SPECIAL_STAR_START = 1000
SPECIAL_STAR_LENGTH = 65
MAX_FINAL_BODIES = 6
CURRENT_BUILD_EXTRA_CLASS_FLAG = True
SECONDARY_TWO_BODY_PERCENT = 33

FIELD24_THRESHOLDS = (
    0.0,
    0.10000000149011612,
    0.10000000149011612,
    0.0,
    0.3499999940395355,
)

EMPTY_SYSTEM_THRESHOLDS = (
    0.0,
    0.4000000059604645,
    0.4000000059604645,
    0.949999988079071,
    0.20000000298023224,
)

PIRATE_SYSTEM_THRESHOLDS = (
    0.25,
    0.15000000596046448,
    0.15000000596046448,
    0.5,
    0.05000000074505806,
)

CONFIRMED_STAR_LABELS = {
    0: "Yellow",
    1: "Green",
}


@dataclass
class PortalDecode:
    input_portal: str
    planet_glyph: int
    supplied_ssi: int
    raw_y: int
    raw_z: int
    raw_x: int
    voxel_y: int
    voxel_z: int
    voxel_x: int
    resolved_system_portal: str
    galaxy_index: int
    tkseed: int
    used_observed_all_zero_correction: bool
    normal_portal_range_warning: str


@dataclass
class MWC:
    value: int
    carry: int
    draw_index: int = 0

    def draw(self, purpose: str, trace: list[dict[str, Any]]) -> int:
        total = (
            MWC_MULTIPLIER * (self.value & MASK32)
            + (self.carry & MASK32)
        )
        self.value = total & MASK32
        self.carry = (total >> 32) & MASK32
        value = self.value
        trace.append(
            {
                "draw_index": self.draw_index,
                "purpose": purpose,
                "value": value,
                "value_hex": f"0x{value:08X}",
            }
        )
        self.draw_index += 1
        return value


def normalize_portal(value: str) -> str:
    text = value.strip().upper()
    if text.startswith("0X"):
        text = text[2:]
    text = re.sub(r"[\s:_\-]+", "", text)
    if not re.fullmatch(r"[0-9A-F]{12}", text):
        raise ValueError(
            "Portal address must contain exactly 12 hexadecimal digits."
        )
    return text


def signed_axis(raw: int, sign_offset: int, modulus: int) -> int:
    return ((raw + sign_offset) % modulus) - sign_offset


def decode_portal(value: str, galaxy_index: int = 0) -> PortalDecode:
    code = normalize_portal(value)
    galaxy_index = int(galaxy_index)
    if not 0 <= galaxy_index <= 255:
        raise ValueError("Galaxy index must be 0..255.")
    planet = int(code[0], 16)
    supplied_ssi = int(code[1:4], 16)
    ssi = supplied_ssi
    raw_y = int(code[4:6], 16)
    raw_z = int(code[6:9], 16)
    raw_x = int(code[9:12], 16)
    corrected = False

    # Exact observed build-6.45 resolution for twelve first glyphs.
    if code == "000000000000":
        ssi = 1
        raw_y = 8
        raw_z = 8
        raw_x = 8
        corrected = True

    tkseed = (
        (raw_x & 0xFFF)
        | ((raw_z & 0xFFF) << 12)
        | ((raw_y & 0xFF) << 24)
        | ((galaxy_index & 0xFF) << 32)
        | ((ssi & 0xFFF) << 40)
    )

    warning = ""
    if not corrected and not (1 <= supplied_ssi <= 0x2FF):
        warning = (
            "SSI is outside the usual portal-system range 0x001..0x2FF; "
            "the game may reject or normalise this address."
        )
    if planet > 5:
        if warning:
            warning += " "
        warning += (
            "Planet glyph is above the normal six-body range; it does not "
            "change the system seed, but the destination planet may be "
            "normalised."
        )

    return PortalDecode(
        input_portal=code,
        planet_glyph=planet,
        supplied_ssi=supplied_ssi,
        raw_y=raw_y,
        raw_z=raw_z,
        raw_x=raw_x,
        voxel_y=signed_axis(raw_y, 0x7F, 0x100),
        voxel_z=signed_axis(raw_z, 0x7FF, 0x1000),
        voxel_x=signed_axis(raw_x, 0x7FF, 0x1000),
        resolved_system_portal=(
            f"0{ssi:03X}{raw_y:02X}{raw_z:03X}{raw_x:03X}"
        ),
        galaxy_index=galaxy_index,
        tkseed=tkseed,
        used_observed_all_zero_correction=corrected,
        normal_portal_range_warning=warning,
    )


def rotate_left_64(value: int, count: int) -> int:
    return (
        ((value << count) | (value >> (64 - count)))
        & MASK64
    )


def rotate_right_32(value: int, count: int) -> int:
    count &= 31
    return (
        ((value >> count) | (value << (32 - count)))
        & MASK32
    )


def mulhi_u32(value: int, scale: int) -> int:
    return ((value & MASK32) * (scale & MASK32)) >> 32


def float32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", value))[0]


def probability_word(value: int) -> float:
    return float32((value & MASK32) / 4294967296.0)


def avalanche_mix_64(value: int) -> int:
    value &= MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_1) & MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_2) & MASK64
    value ^= value >> 33
    return value & MASK64


def threefry4x64_20(
    counter: tuple[int, int, int, int],
    key: tuple[int, int, int, int],
) -> tuple[int, int, int, int]:
    """
    Exact Threefry4x64-20 primitive used by the mapped selector routine.

    V2K called the related round structure "Threefish-256". Static inspection
    of the counter mode and 20-round schedule shows that the exact primitive
    here is Threefry4x64-20.
    """
    keys = [word & MASK64 for word in key]
    keys.append(
        THREEFRY_C240
        ^ keys[0]
        ^ keys[1]
        ^ keys[2]
        ^ keys[3]
    )

    state = [
        (counter[0] + keys[0]) & MASK64,
        (counter[1] + keys[1]) & MASK64,
        (counter[2] + keys[2]) & MASK64,
        (counter[3] + keys[3]) & MASK64,
    ]

    for round_index in range(20):
        rotation_a, rotation_b = (
            THREEFRY_ROTATIONS[round_index % 8]
        )

        a = (state[0] + state[1]) & MASK64
        b = rotate_left_64(state[1], rotation_a) ^ a
        c = (state[2] + state[3]) & MASK64
        d = rotate_left_64(state[3], rotation_b) ^ c

        # Threefry4x64 permutation [0, 3, 2, 1].
        state = [a, d, c, b]

        if round_index % 4 == 3:
            subkey = round_index // 4 + 1
            state[0] = (
                state[0] + keys[subkey % 5]
            ) & MASK64
            state[1] = (
                state[1] + keys[(subkey + 1) % 5]
            ) & MASK64
            state[2] = (
                state[2] + keys[(subkey + 2) % 5]
            ) & MASK64
            state[3] = (
                state[3]
                + keys[(subkey + 3) % 5]
                + subkey
            ) & MASK64

    return tuple(state)


def select_system_generator_word(
    decoded: PortalDecode,
) -> dict[str, Any]:
    ssi = (decoded.tkseed >> 40) & 0xFFF
    work_index = (ssi - 1) & 0xFFFF

    if work_index == 0:
        counter = 0
        word_index = 0
    elif work_index < 8:
        counter = 0
        word_index = work_index
    else:
        adjusted = work_index - 8
        word_index = adjusted & 7
        counter = (
            ((adjusted - word_index) >> 3) + 1
        )

    spatial_key = decoded.tkseed & 0xFFFFFFFFFF
    block = threefry4x64_20(
        (counter, 0, 0, 0),
        (spatial_key, 0, 0, 0),
    )

    words: list[int] = []
    for qword in block:
        words.append(qword & MASK32)
        words.append((qword >> 32) & MASK32)

    return {
        "spatial_key": spatial_key,
        "work_index": work_index,
        "threefry_counter": counter,
        "threefry_word_index": word_index,
        "threefry_block": list(block),
        "threefry_words_u32": words,
        "selected_word": words[word_index],
    }


def coordinate_config(decoded: PortalDecode) -> dict[str, Any]:
    squared = (
        decoded.voxel_x * decoded.voxel_x
        + decoded.voxel_y * decoded.voxel_y
        + decoded.voxel_z * decoded.voxel_z
    )
    distance = math.sqrt(squared)
    distance_integer = int(distance)

    range_a_length = 1
    range_b_length = 1
    if distance_integer < 8:
        range_a_length = 0
        range_b_length = 0

    # The config constructor at RVA 0x1F99FE0 zeroes +0x74.
    # RVA 0x13B06BA writes a nonzero radial cutoff only inside
    # 8 < distance < 1440. Outside that band the exact value remains 0.
    radial_cutoff = 0
    if 8 < distance_integer < 1440:
        subtraction = int(
            ((distance_integer - 8) * 120) / 1440
        )
        subtraction = max(0, min(120, subtraction))
        radial_cutoff = (
            BASE_SYSTEM_INDEX_CUTOFF - subtraction
        )

    return {
        "distance": distance,
        "distance_integer": distance_integer,
        "range_a_length": range_a_length,
        "range_b_length": range_b_length,
        "base_system_index_cutoff": (
            BASE_SYSTEM_INDEX_CUTOFF
        ),
        "radial_star_cutoff": radial_cutoff,
        "special_star_start": SPECIAL_STAR_START,
        "special_star_length": SPECIAL_STAR_LENGTH,
    }


def make_mwc_from_word(selected_word: int) -> MWC:
    value = selected_word & MASK32
    return MWC(
        value=value if value != 0 else 1,
        carry=(
            rotate_right_32(value, 16) ^ value
        ) & MASK32,
    )


def make_planet_mwc(tkseed: int) -> tuple[int, MWC]:
    mixed = avalanche_mix_64(tkseed)
    low = mixed & MASK32
    high = (mixed >> 32) & MASK32
    return (
        mixed,
        MWC(
            value=low if low != 0 else 1,
            carry=(
                rotate_right_32(low, 16)
                ^ high
                ^ low
            ) & MASK32,
        ),
    )


def predict_system(decoded: PortalDecode) -> dict[str, Any]:
    selector = select_system_generator_word(decoded)
    config = coordinate_config(decoded)
    trace: list[dict[str, Any]] = []
    rng = make_mwc_from_word(selector["selected_word"])
    system_index = selector["work_index"]

    first = rng.draw("system_first", trace)
    star_type = 0
    first_special_range = False
    second_special_range = False

    if system_index >= BASE_SYSTEM_INDEX_CUTOFF:
        if mulhi_u32(first, 100) < 30:
            preliminary = rng.draw(
                "preliminary_star_type", trace
            )
            star_type = (
                mulhi_u32(preliminary, 3) + 1
            )

        relative = (
            system_index - BASE_SYSTEM_INDEX_CUTOFF
        )
        if (
            config["range_b_length"] > 0
            and 0 <= relative
            < config["range_b_length"]
        ):
            first_special_range = True
            star_type = 0

        relative -= config["range_b_length"]
        if (
            config["range_a_length"] > 0
            and 0 <= relative
            < config["range_a_length"]
            and system_index < SPECIAL_STAR_START
        ):
            second_special_range = True
            star_type = 0

        primary_draw = rng.draw(
            "primary_count_1_to_6", trace
        )
        primary_count = (
            mulhi_u32(primary_draw, 6) + 1
        )

        if (
            config["radial_star_cutoff"] < 10
            and star_type == 0
            and not first_special_range
            and not second_special_range
        ):
            internal_draw = rng.draw(
                "internal_class_limit", trace
            )
            internal_class_limit = mulhi_u32(
                internal_draw,
                primary_count + 1,
            )
        else:
            internal_class_limit = 0
    else:
        auxiliary = rng.draw(
            "inner_region_auxiliary", trace
        )
        primary_count = (first >> 30) + 3
        internal_class_limit = (
            mulhi_u32(auxiliary, primary_count) + 1
        )

    system_kind_draw = rng.draw(
        "system_kind_0_to_6", trace
    )
    system_kind = mulhi_u32(system_kind_draw, 7)

    system_secondary_probability_draw = rng.draw(
        "system_secondary_probability_field", trace
    )

    field8_draw = rng.draw(
        "source_field8_0_to_2", trace
    )
    source_field8 = mulhi_u32(field8_draw, 3)

    field0c_draw = rng.draw(
        "source_field0c_0_to_2", trace
    )
    source_field0c = mulhi_u32(field0c_draw, 3)

    if system_index < config["radial_star_cutoff"]:
        star_draw = rng.draw(
            "radial_star_type_1_to_3", trace
        )
        star_type = mulhi_u32(star_draw, 3) + 1

    if (
        SPECIAL_STAR_START
        <= system_index
        < SPECIAL_STAR_START + SPECIAL_STAR_LENGTH
    ):
        star_type = 4

    field24_draw = rng.draw(
        "source_field24_probability", trace
    )
    threshold = (
        FIELD24_THRESHOLDS[star_type]
        if 0 <= star_type
        < len(FIELD24_THRESHOLDS)
        else 0.0
    )
    source_field24 = (
        probability_word(field24_draw)
        < threshold
    )

    # Static control flow consumes no follow-up draw when field24 is already
    # true. When false, one of the two mutually exclusive follow-up routes
    # consumes exactly one draw.
    if not source_field24:
        rng.draw(
            "field24_false_followup", trace
        )

    capacity = MAX_FINAL_BODIES - primary_count
    if capacity < 1:
        secondary_count = 0
    else:
        secondary_draw = rng.draw(
            "secondary_count_1_or_2", trace
        )
        secondary_count = 1
        if (
            mulhi_u32(secondary_draw, 100)
            < SECONDARY_TWO_BODY_PERCENT
            and capacity >= 2
        ):
            secondary_count = 2

    special_seed_layout = False
    force_six_special_bodies = False

    if star_type == 4:
        total_before_special = (
            primary_count + secondary_count
        )
        primary_count = 0
        secondary_count = total_before_special

        special_roll_one = rng.draw(
            "special_star_roll_15_percent", trace
        )
        if mulhi_u32(special_roll_one, 100) < 15:
            special_seed_layout = True
            special_roll_two = rng.draw(
                "special_star_roll_66_percent",
                trace,
            )
            if (
                mulhi_u32(special_roll_two, 100)
                < 66
            ):
                force_six_special_bodies = True

        if force_six_special_bodies:
            primary_count = 0
            secondary_count = MAX_FINAL_BODIES

    # Exact standalone replay of the scalar state written by the native
    # semantic generator. The earlier V2M model exposed the raw 0..2 source
    # draw but did not apply the empty-system or pirate-system follow-up
    # branches. Those branches are now reproduced directly from the same MWC
    # stream and current-build probability tables.
    source_system_kind = int(source_field0c)
    empty_roll_word = next(
        (
            int(row["value"])
            for row in trace
            if row["purpose"] == "field24_false_followup"
        ),
        None,
    )
    if (
        empty_roll_word is not None
        and probability_word(empty_roll_word)
        < EMPTY_SYSTEM_THRESHOLDS[star_type]
    ):
        source_system_kind = 7

    system_secondary_probability_unit = probability_word(
        system_secondary_probability_draw
    )
    decoded_field_234 = (
        2
        if system_secondary_probability_unit < 0.10000000149011612
        else 0
        if system_secondary_probability_unit < 0.30000001192092896
        else 1
    )
    decoded_field_23c = int(source_field8)
    if source_field24:
        decoded_field_234 = 0
        decoded_field_23c = 0

    pirate_system = False
    if (
        (star_type != 0 or internal_class_limit <= 0)
        and not source_field24
        and source_system_kind != 7
    ):
        pirate_rng = MWC(
            value=int(rng.value),
            carry=int(rng.carry),
            draw_index=int(rng.draw_index),
        )
        pirate_trace: list[dict[str, Any]] = []
        pirate_word = pirate_rng.draw(
            "pirate_system_probability", pirate_trace
        )
        pirate_system = (
            probability_word(pirate_word)
            < PIRATE_SYSTEM_THRESHOLDS[star_type]
        )
        if pirate_system:
            decoded_field_234 = 3
            decoded_field_23c = 3

    return {
        "selector": selector,
        "coordinate_config": config,
        "system_index": system_index,
        "primary_count": primary_count,
        "secondary_count": secondary_count,
        "final_count": (
            primary_count + secondary_count
        ),
        "internal_class_limit": (
            internal_class_limit
        ),
        "star_type_raw": star_type,
        "star_colour_confirmed": (
            CONFIRMED_STAR_LABELS.get(star_type)
        ),
        "star_colour_status": (
            "CONFIRMED"
            if star_type in CONFIRMED_STAR_LABELS
            else "RAW_VALUE_ONLY_UNCONFIRMED_LABEL"
        ),
        "system_kind": system_kind,
        "source_system_kind": source_system_kind,
        "in_empty_system": source_system_kind == 7,
        "in_abandoned_system": bool(source_field24),
        "in_gas_giant_system": bool(force_six_special_bodies),
        "in_pirate_system": bool(pirate_system),
        "raw2c_auxiliary_flag": bool(special_seed_layout),
        "decoded_field_230": int(system_kind),
        "decoded_field_234": int(decoded_field_234),
        "decoded_field_23C": int(decoded_field_23c),
        "source_field8": source_field8,
        "source_field0c": source_field0c,
        "source_field24": source_field24,
        "special_seed_layout": special_seed_layout,
        "force_six_special_bodies": (
            force_six_special_bodies
        ),
        "first_special_range": first_special_range,
        "second_special_range": (
            second_special_range
        ),
        "rng_trace": trace,
        "final_rng_state": {
            "value": rng.value,
            "carry": rng.carry,
            "draws_consumed": rng.draw_index,
        },
    }


def combine_and_mix_seed(
    low_word: int,
    high_word: int,
) -> tuple[int, int]:
    raw = (
        ((high_word & MASK32) << 32)
        | (low_word & MASK32)
    )
    return raw, avalanche_mix_64(raw)


def predict_planet_seeds(
    decoded: PortalDecode,
    system: dict[str, Any],
) -> dict[str, Any]:
    """Replay exact candidate classes and root planet seeds.

    This delegates to the standalone clean-room candidate-array schedule. The
    schedule normalizes signed coordinate extrema before initializing its MWC
    state and preserves the independent secondary class draw proven by the
    mapped native route.
    """
    primary_count = int(system["primary_count"])
    secondary_count = int(system["secondary_count"])
    final_count = primary_count + secondary_count

    replay = candidate_arrays.replay_candidate_arrays(
        int(decoded.tkseed),
        primary_count=primary_count,
        secondary_count=secondary_count,
        weather_suppression=int(bool(system.get("force_six_special_bodies"))),
        flag_252=int(bool(system.get("special_seed_layout"))),
        derived_source_flag=int(system["internal_class_limit"]),
        global_extra_records_flag=(
            candidate_arrays.CURRENT_BUILD_EXTRA_RECORDS_FLAG
        ),
    )

    bodies: list[dict[str, Any]] = []
    classes = replay["deep_classes"]
    seeds = replay["root_seeds"]
    raw_materials = replay["raw_seed_materials"]
    seed_indices = replay["seed_draw_indices"]
    class_indices = replay["classification_draw_indices"]
    parents = replay["auxiliary_parent_indices"]
    valid_flags = replay["valid_flags"]
    special = replay["branch"].startswith("special_")

    for slot in range(final_count):
        if not valid_flags[slot] or seeds[slot] is None or classes[slot] is None:
            raise RuntimeError(
                f"Candidate-array replay did not produce active slot {slot}."
            )
        if special:
            kind = "special"
        elif slot < primary_count:
            kind = "primary"
        elif class_indices[slot] is None:
            kind = "inserted_secondary"
        else:
            kind = "secondary"

        draw_indices = list(seed_indices[slot])
        if class_indices[slot] is not None:
            draw_indices.insert(0, int(class_indices[slot]))
        raw = int(raw_materials[slot])
        seed = int(seeds[slot])
        body = {
            "slot": slot,
            "kind": kind,
            "source_class": int(classes[slot]),
            "seed": seed,
            "seed_hex": f"0x{seed:016X}",
            "raw_seed_material": raw,
            "raw_seed_material_hex": f"0x{raw:016X}",
            "draw_indices": draw_indices,
            "auxiliary_parent_index": int(parents[slot]),
            "seed_valid": int(valid_flags[slot]),
        }
        if class_indices[slot] is not None:
            body["classification_draw_index"] = int(class_indices[slot])
        bodies.append(body)

    return {
        "mixed_system_seed": int(replay["mixed_system_seed"]),
        "normalized_packed": int(replay["normalized_packed"]),
        "normalization": replay["normalization"],
        "class_array": [int(classes[i]) for i in range(final_count)],
        "bodies": bodies,
        "rng_trace": replay["draw_trace"],
        "final_rng_state": {
            "value": int(replay["final_state"]["low"]),
            "carry": int(replay["final_state"]["high"]),
            "draws_consumed": int(replay["draw_count"]),
        },
        "branch": replay["branch"],
        "global_extra_records_flag": int(
            replay["global_extra_records_flag"]
        ),
    }

def predict_address(portal: str, galaxy_index: int = 0) -> dict[str, Any]:
    decoded = decode_portal(portal, galaxy_index)
    system = predict_system(decoded)
    planets = predict_planet_seeds(
        decoded, system
    )
    return {
        "version": VERSION,
        "mode": "OFFLINE_NO_NMS_PROCESS",
        "decoded": asdict(decoded),
        "system": system,
        "planet_seed_generation": planets,
        "limitations": {
            "biome_prediction": "NOT_YET_PORTED",
            "biome_subtype_prediction": (
                "NOT_YET_PORTED"
            ),
            "weather_prediction": "NOT_YET_PORTED",
            "sentinel_prediction": (
                "NOT_YET_PORTED"
            ),
            "star_labels_2_3_4": (
                "RAW_VALUES_ONLY"
            ),
        },
    }


def load_vectors(path: Path) -> list[dict[str, Any]]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, list):
        raise ValueError(
            "Known vector file must contain a JSON list."
        )
    return value


def self_test(
    vectors: list[dict[str, Any]],
) -> list[str]:
    lines: list[str] = []
    total_seeds = 0
    matched_seeds = 0

    for vector in vectors:
        prediction = predict_address(
            str(vector["input_portal"])
        )
        decoded = prediction["decoded"]
        system = prediction["system"]
        planets = prediction[
            "planet_seed_generation"
        ]

        expected_tkseed = int(
            str(vector["tkseed"]), 16
        )
        expected_selector = int(
            str(vector["system_selector_word"]),
            16,
        )
        expected_seeds = [
            int(str(seed), 16)
            for seed in vector["planet_seeds"]
        ]
        actual_seeds = [
            int(body["seed"])
            for body in planets["bodies"]
        ]
        actual_classes = [
            int(value)
            for value in planets["class_array"]
        ]

        checks = {
            "resolved": (
                decoded["resolved_system_portal"]
                == vector["resolved_system_portal"]
            ),
            "tkseed": (
                int(decoded["tkseed"])
                == expected_tkseed
            ),
            "threefry_counter": (
                int(
                    system["selector"][
                        "threefry_counter"
                    ]
                )
                == int(vector["threefry_counter"])
            ),
            "threefry_word_index": (
                int(
                    system["selector"][
                        "threefry_word_index"
                    ]
                )
                == int(
                    vector["threefry_word_index"]
                )
            ),
            "selector_word": (
                int(
                    system["selector"][
                        "selected_word"
                    ]
                )
                == expected_selector
            ),
            "primary_count": (
                int(system["primary_count"])
                == int(vector["primary_count"])
            ),
            "secondary_count": (
                int(system["secondary_count"])
                == int(
                    vector["secondary_count"]
                )
            ),
            "star_type": (
                int(system["star_type_raw"])
                == int(vector["star_type_raw"])
            ),
            "classes": (
                actual_classes
                == [
                    int(value)
                    for value in vector[
                        "planet_classes"
                    ]
                ]
            ),
            "seeds": (
                actual_seeds == expected_seeds
            ),
        }

        if not all(checks.values()):
            raise AssertionError(
                "Known vector failed for "
                f"{vector['input_portal']}: "
                f"{checks}"
            )

        total_seeds += len(expected_seeds)
        matched_seeds += sum(
            got == expected
            for got, expected in zip(
                actual_seeds,
                expected_seeds,
            )
        )

        lines.append(
            "SYSTEM="
            f"{vector['input_portal']} "
            "STATUS=PASS "
            f"COUNT={system['primary_count']}+"
            f"{system['secondary_count']}="
            f"{system['final_count']} "
            f"STAR={system['star_type_raw']} "
            "SELECTOR=0x"
            f"{system['selector']['selected_word']:08X} "
            f"SEEDS={len(expected_seeds)}/"
            f"{len(expected_seeds)}"
        )

    lines.append(
        f"KNOWN_SYSTEMS_MATCHED={len(vectors)}/"
        f"{len(vectors)}"
    )
    lines.append(
        f"ACTIVE_PLANET_SEEDS_MATCHED="
        f"{matched_seeds}/{total_seeds}"
    )
    return lines


def known_labels(
    vectors: list[dict[str, Any]],
    portal: str,
    resolved: str,
) -> list[str]:
    for vector in vectors:
        if (
            vector.get("input_portal") == portal
            or vector.get(
                "resolved_system_portal"
            )
            == resolved
        ):
            return [
                str(label)
                for label in vector.get(
                    "labels", []
                )
            ]
    return []


def format_report(
    prediction: dict[str, Any],
    labels: list[str],
) -> str:
    decoded = prediction["decoded"]
    system = prediction["system"]
    selector = system["selector"]
    config = system["coordinate_config"]
    planets = prediction[
        "planet_seed_generation"
    ]

    star_label = (
        system["star_colour_confirmed"]
        or (
            "UNCONFIRMED_LABEL_FOR_RAW_"
            f"{system['star_type_raw']}"
        )
    )

    lines = [
        "FIBONACCI NMS ADDRESS-ONLY SYSTEM + PLANET-SEED PREDICTOR V2M",
        f"Version={VERSION}",
        "Mode=OFFLINE_NO_NMS_PROCESS",
        "",
        "ADDRESS",
        "-------",
        f"input_portal={decoded['input_portal']}",
        f"planet_glyph={decoded['planet_glyph']}",
        "resolved_system_portal="
        f"{decoded['resolved_system_portal']}",
        f"tkseed=0x{decoded['tkseed']:016X}",
        f"ssi=0x{decoded['supplied_ssi']:03X}",
        f"voxel_x={decoded['voxel_x']}",
        f"voxel_y={decoded['voxel_y']}",
        f"voxel_z={decoded['voxel_z']}",
        "all_zero_correction="
        f"{decoded['used_observed_all_zero_correction']}",
    ]

    if decoded["normal_portal_range_warning"]:
        lines.append(
            "ADDRESS_WARNING="
            f"{decoded['normal_portal_range_warning']}"
        )

    lines.extend(
        [
            "",
            "THREEFRY SYSTEM SELECTOR",
            "------------------------",
            f"spatial_key=0x"
            f"{selector['spatial_key']:010X}",
            f"work_index={selector['work_index']}",
            f"counter={selector['threefry_counter']}",
            "word_index="
            f"{selector['threefry_word_index']}",
            f"selected_word=0x"
            f"{selector['selected_word']:08X}",
            "",
            "COORDINATE CONFIG",
            "-----------------",
            f"distance={config['distance']:.6f}",
            "distance_integer="
            f"{config['distance_integer']}",
            "radial_star_cutoff="
            f"{config['radial_star_cutoff']}",
            "",
            "PREDICTED SYSTEM",
            "----------------",
            f"primary_count={system['primary_count']}",
            f"secondary_count="
            f"{system['secondary_count']}",
            f"final_count={system['final_count']}",
            f"star_type_raw="
            f"{system['star_type_raw']}",
            f"star_colour={star_label}",
            "star_colour_status="
            f"{system['star_colour_status']}",
            f"system_kind={system['system_kind']}",
            "internal_class_limit="
            f"{system['internal_class_limit']}",
            "special_seed_layout="
            f"{system['special_seed_layout']}",
            "force_six_special_bodies="
            f"{system['force_six_special_bodies']}",
            "",
            "PREDICTED PLANET GENERATION SEEDS",
            "---------------------------------",
        ]
    )

    for body in planets["bodies"]:
        slot = int(body["slot"])
        label = (
            labels[slot]
            if slot < len(labels)
            else "UNKNOWN"
        )
        lines.append(
            f"slot={slot} "
            f"kind={body['kind']} "
            f"class={body['source_class']} "
            f"seed={body['seed_hex']} "
            "draw_indices="
            f"{body['draw_indices']} "
            f"label={label}"
        )

    lines.extend(
        [
            "",
            "VALIDITY STATUS",
            "---------------",
            "address_only_body_count_prediction=IMPLEMENTED",
            "address_only_raw_star_type_prediction=IMPLEMENTED",
            "address_only_planet_seed_prediction=IMPLEMENTED",
            "planet_biome_prediction=NOT_YET_PORTED",
            "planet_biome_subtype_prediction=NOT_YET_PORTED",
            "weather_and_sentinel_prediction=NOT_YET_PORTED",
            "",
            "CORRECTION TO V2K TERMINOLOGY",
            "-----------------------------",
            "The mapped 20-round counter primitive is Threefry4x64-20.",
            "It is related to Threefish/Skein and uses the same C240 parity",
            "constant, but V2K's label Threefish-256 was not the precise",
            "name of the generator primitive.",
        ]
    )

    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("portal", nargs="?")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--galaxy", type=int, default=0)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--vectors", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    vector_path = (
        args.vectors
        or base / "known_vectors_v2j.json"
    )
    vectors = load_vectors(vector_path)

    if args.self_test:
        lines = self_test(vectors)
        print("ADDRESS_ONLY_V2M_SELF_TEST=PASS")
        for line in lines:
            print(line)
        return 0

    portal = args.portal
    if not portal:
        portal = input(
            "Enter a 12-glyph portal address: "
        ).strip()

    prediction = predict_address(portal, args.galaxy)

    if args.json:
        output = (
            json.dumps(prediction, indent=2)
            + "\n"
        )
    else:
        decoded = prediction["decoded"]
        labels = known_labels(
            vectors,
            decoded["input_portal"],
            decoded["resolved_system_portal"],
        )
        output = format_report(
            prediction, labels
        )

    print(output, end="")

    if args.report:
        args.report.parent.mkdir(
            parents=True, exist_ok=True
        )
        args.report.write_text(
            output, encoding="utf-8"
        )
        print(f"REPORT={args.report}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
