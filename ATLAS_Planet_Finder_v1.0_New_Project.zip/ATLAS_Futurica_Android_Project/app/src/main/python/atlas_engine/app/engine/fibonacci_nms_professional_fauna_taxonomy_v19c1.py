#!/usr/bin/env python3
"""Professional fauna taxonomy presentation layer for Fibonacci APF V19C1.

This module maps exact native creature descriptor tokens to professional
profile labels and separately exposes community archetype signals. Signals
are never represented as guaranteed individual species predictions.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

VERSION = "19C1.0.0"
DESCRIPTOR_FIELDS = (
    "creature_descriptor_primary",
    "creature_descriptor_aux_1",
    "creature_descriptor_aux_2",
    "creature_descriptor_aux_3",
)


def load_json(path: Path | str) -> Any:
    with Path(path).open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def _indexes(
    taxonomy_path: Path | str,
    descriptor_path: Path | str,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    taxonomy = load_json(taxonomy_path)
    descriptor_catalog = load_json(descriptor_path)
    descriptor_by_token = {
        str(row["internal_descriptor"]).upper(): row
        for row in descriptor_catalog.get("rows", [])
    }
    archetypes = {}
    for row in (
        list(taxonomy.get("standard_archetypes", []))
        + list(taxonomy.get("special_archetypes", []))
    ):
        archetypes[str(row["archetype_id"])] = row
    return taxonomy, descriptor_by_token, archetypes


def verify_static(
    taxonomy_path: Path | str,
    descriptor_path: Path | str,
) -> dict[str, Any]:
    taxonomy, descriptors, archetypes = _indexes(
        taxonomy_path,
        descriptor_path,
    )
    standard = list(taxonomy.get("standard_archetypes", []))
    special = list(taxonomy.get("special_archetypes", []))
    aliases = len(standard) + len(special) + sum(len(row.get("aliases", [])) for row in standard + special)
    flying = archetypes.get("flying_snake", {})
    titan = archetypes.get("titan_worm", {})
    checks = {
        "native_descriptor_tokens_30": len(descriptors) == 30,
        "standard_archetypes_43": len(standard) == 43,
        "special_archetypes_9": len(special) == 9,
        "taxonomy_aliases_107": aliases == 107,
        "flying_snake_present": flying.get("display_name") == "Flying Snake",
        "titan_worm_present": titan.get("display_name") == "Titan Worm",
        "flying_snake_titan_worm_separate": (
            flying.get("archetype_id") != titan.get("archetype_id")
            and flying.get("native_or_community_genus")
            != titan.get("native_or_community_genus")
        ),
        "giant_does_not_map_to_titan_worm": (
            "titan_worm"
            not in descriptors.get("GIANT", {}).get("archetype_ids", [])
        ),
        "all_native_tokens_preserved": all(
            bool(row.get("native_token_preserved"))
            for row in descriptors.values()
        ),
        "no_individual_prediction_claims": all(
            not bool(row.get("individual_address_prediction_available"))
            for row in standard + special
        ),
    }
    return {
        "version": VERSION,
        "exact": all(checks.values()),
        "checks": checks,
        "metrics": {
            "native_descriptor_tokens": f"{len(descriptors)}/30",
            "standard_archetypes": f"{len(standard)}/43",
            "special_archetypes": f"{len(special)}/9",
            "taxonomy_aliases": f"{aliases}/107",
        },
    }


def enrich_row(
    row: dict[str, Any],
    taxonomy_path: Path | str,
    descriptor_path: Path | str,
) -> dict[str, Any]:
    _, descriptor_by_token, archetypes = _indexes(
        taxonomy_path,
        descriptor_path,
    )
    tokens = [
        str(row.get(field, "") or "").upper()
        for field in DESCRIPTOR_FIELDS
    ]
    mapped = [
        descriptor_by_token.get(token)
        for token in tokens
    ]
    profile_labels = [
        str(item.get("display_label", token))
        if item is not None else token
        for token, item in zip(tokens, mapped)
    ]
    profile_kinds = [
        str(item.get("descriptor_kind", "unknown"))
        if item is not None else "unknown"
        for item in mapped
    ]
    archetype_ids: list[str] = []
    for item in mapped:
        if not item:
            continue
        for archetype_id in item.get("archetype_ids", []):
            value = str(archetype_id)
            if value not in archetype_ids:
                archetype_ids.append(value)

    signal_rows = [
        archetypes[archetype_id]
        for archetype_id in archetype_ids
        if archetype_id in archetypes
    ]
    signal_names = [str(item["display_name"]) for item in signal_rows]
    signal_genera = [
        str(item.get("native_or_community_genus", ""))
        for item in signal_rows
        if item.get("native_or_community_genus")
    ]
    habitats: list[str] = []
    for item in signal_rows:
        habitat = str(item.get("habitat", "")).strip()
        if habitat and habitat not in habitats:
            habitats.append(habitat)

    exact = bool(
        len(tokens) == 4
        and all(token in descriptor_by_token for token in tokens)
    )
    result = {
        "fauna_descriptor_tokens": tokens,
        "fauna_descriptor_profile_labels": profile_labels,
        "fauna_descriptor_profile_kinds": profile_kinds,
        "fauna_descriptor_primary_display": profile_labels[0],
        "fauna_descriptor_profile_summary": "; ".join(profile_labels),
        "fauna_community_archetype_signal_ids": archetype_ids,
        "fauna_community_archetype_signals": signal_names,
        "fauna_community_archetype_signal_summary": (
            ", ".join(signal_names) if signal_names else "No specific archetype signal"
        ),
        "fauna_community_genus_signals": signal_genera,
        "fauna_habitat_signals": habitats,
        "fauna_descriptor_profile_exact": exact,
        "fauna_descriptor_profile_provenance": (
            "exact_native_descriptor_to_professional_profile_v19c1"
        ),
        "fauna_community_taxonomy_provenance": (
            "community_taxonomy_signal_not_game_localisation"
        ),
        "fauna_individual_archetype_prediction_available": False,
        "fauna_individual_species_guaranteed": False,
        "fauna_taxonomy_claim": (
            "Exact native descriptor profile; community archetype signals "
            "are not guaranteed individual species."
        ),
        "fauna_titan_worm_prediction_available": False,
        "fauna_diplo_prediction_available": False,
    }
    return result


def run_regression(
    taxonomy_path: Path | str,
    descriptor_path: Path | str,
    creature_regression_path: Path | str,
) -> dict[str, Any]:
    static = verify_static(taxonomy_path, descriptor_path)
    regression = load_json(creature_regression_path)
    metrics = {
        "descriptor_tokens_preserved": {"correct": 0, "total": 0},
        "descriptor_profile_labels": {"correct": 0, "total": 0},
        "descriptor_profile_rows": {"correct": 0, "total": 0},
        "individual_prediction_boundary": {"correct": 0, "total": 0},
        "flying_snake_titan_worm_separation": {"correct": 0, "total": 2},
    }
    failures: list[dict[str, Any]] = []
    for row in regression.get("rows", []):
        expected = row["expected_descriptors"]
        source = {
            "creature_descriptor_primary": expected["primary"],
            "creature_descriptor_aux_1": expected["aux_1"],
            "creature_descriptor_aux_2": expected["aux_2"],
            "creature_descriptor_aux_3": expected["aux_3"],
        }
        enriched = enrich_row(source, taxonomy_path, descriptor_path)
        row_exact = bool(enriched["fauna_descriptor_profile_exact"])
        metrics["descriptor_profile_rows"]["total"] += 1
        metrics["descriptor_profile_rows"]["correct"] += int(row_exact)
        metrics["individual_prediction_boundary"]["total"] += 1
        boundary_ok = (
            enriched["fauna_individual_archetype_prediction_available"] is False
            and enriched["fauna_individual_species_guaranteed"] is False
            and enriched["fauna_titan_worm_prediction_available"] is False
            and enriched["fauna_diplo_prediction_available"] is False
        )
        metrics["individual_prediction_boundary"]["correct"] += int(boundary_ok)
        for index, field in enumerate(DESCRIPTOR_FIELDS):
            metrics["descriptor_tokens_preserved"]["total"] += 1
            token_ok = enriched["fauna_descriptor_tokens"][index] == source[field]
            metrics["descriptor_tokens_preserved"]["correct"] += int(token_ok)
            metrics["descriptor_profile_labels"]["total"] += 1
            label_ok = bool(enriched["fauna_descriptor_profile_labels"][index])
            metrics["descriptor_profile_labels"]["correct"] += int(label_ok)
        if not row_exact or not boundary_ok:
            failures.append({
                "planet_portal": row.get("planet_portal"),
                "row_exact": row_exact,
                "boundary_ok": boundary_ok,
            })

    flying = enrich_row({
        "creature_descriptor_primary": "FLYINGSNAKE",
        "creature_descriptor_aux_1": "ONLYSNAKE",
        "creature_descriptor_aux_2": "DEFAULT",
        "creature_descriptor_aux_3": "EMPTY",
    }, taxonomy_path, descriptor_path)
    first = (
        "Flying Snake" in flying["fauna_community_archetype_signals"]
        and "Titan Worm" not in flying["fauna_community_archetype_signals"]
    )
    second = (
        flying["fauna_titan_worm_prediction_available"] is False
        and "titan_worm"
        not in flying["fauna_community_archetype_signal_ids"]
    )
    metrics["flying_snake_titan_worm_separation"]["correct"] = int(first) + int(second)

    for metric in metrics.values():
        metric["exact"] = bool(
            metric["total"] > 0
            and metric["correct"] == metric["total"]
        )
    exact = bool(static["exact"] and all(m["exact"] for m in metrics.values()))
    return {
        "version": VERSION,
        "status": (
            "PASS_FAUNA_TAXONOMY_PRESENTATION_REGRESSION_V19C1_EXACT"
            if exact else
            "ERROR_FAUNA_TAXONOMY_PRESENTATION_REGRESSION_V19C1"
        ),
        "exact": exact,
        "static": static,
        "metrics": metrics,
        "failure_count": len(failures),
        "failures": failures,
        "claim_boundary": {
            "descriptor_profiles_exact": True,
            "community_archetype_signals_separate": True,
            "individual_species_prediction_complete": False,
            "titan_worm_filter_enabled": False,
            "diplo_filter_enabled": False,
        },
    }
