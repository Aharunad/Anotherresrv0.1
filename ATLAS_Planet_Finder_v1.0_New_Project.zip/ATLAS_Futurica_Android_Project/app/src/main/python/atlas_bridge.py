"""ATLAS APF Android bridge. Search runs locally inside the app via Chaquopy."""
import json, sys, threading, time, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'atlas_engine'
APP = ROOT / 'app'
if str(APP) not in sys.path:
    sys.path.insert(0, str(APP))

import any_planet_finder_core as core

_lock = threading.RLock()
_cancel = threading.Event()
_pause = threading.Event()
_state = {"running": False, "paused": False, "status": "Ready", "tested_systems": 0,
          "tested_planets": 0, "matches": [], "error": None, "system_limit": 0,
          "batch": 64, "until_found": True, "target": 1, "request": {}}
_worker = None
_last_args = None
_next_start = 0

def _progress(done, total, message):
    with _lock:
        _state["tested_systems"] = int(done or 0)
        _state["status"] = str(message or "Searching")

def _paused():
    while _pause.is_set() and not _cancel.is_set():
        time.sleep(0.15)
    return False

def _selected(value):
    if value is None:
        return None
    text = str(value).strip()
    return None if not text or text.lower() in ("any", "all", "either", "none", "unlimited") else text

def _map_filters(filters, portal, galaxy, target):
    args = {"anchor_portal": portal, "galaxy": galaxy, "result_limit": target,
            "system_workers": 1, "progress": _progress, "cancel": _cancel.is_set,
            "pause": _paused}
    if filters.get('paradise'): args['paradise'] = True
    if filters.get('mustWater') or filters.get('water') == 'Must have water': args['water'] = True
    if filters.get('extreme') in ('No', 'exclude'): args['non_extreme'] = True
    elif filters.get('extreme') == 'Yes': args['weather_extreme'] = True
    weather = _selected(filters.get('weather'))
    if weather:
        if weather == 'Calm / pleasant': args['weather_clear'] = True
        elif weather == 'Non-extreme': args['non_extreme'] = True
        elif weather == 'Extreme': args['weather_extreme'] = True
        else: args['weather_family'] = weather
    for ui_key, core_key in [('size', 'world_size'), ('biome', 'biome'), ('race', 'dominant_race')]:
        value = _selected(filters.get(ui_key))
        if value: args[core_key] = value
    economy = _selected(filters.get('economy'))
    if economy: args['economy_tier'] = economy
    if filters.get('gasGiant'): args['in_gas_giant_system'] = True
    if filters.get('rings') == 'Has rings': args['ringed'] = True
    elif filters.get('rings') == 'No rings': args['ringed'] = False
    if filters.get('glowGrass'): args['glowing_grass'] = True
    if filters.get('mustFlora'): args['flora_level'] = 1
    if filters.get('resources') == 'High': args['resource_level'] = 3
    elif filters.get('resources') == 'Low': args['resource_level'] = 1
    grass = filters.get('grass') or []
    if isinstance(grass, str): grass = [grass]
    if len(grass) == 1: args['either_grass_colour'] = grass[0]
    colors = filters.get('colors') or {}
    for ui_key, core_key in [('sky', 'sky_palette_colour'), ('waterColour', 'generated_water_colour')]:
        vals = colors.get(ui_key) or []
        if isinstance(vals, str): vals = [vals]
        if len(vals) == 1: args[core_key] = vals[0]
    terrain = filters.get('terrainSettings', filters.get('terrain_settings', [])) or []
    if isinstance(terrain, str): terrain = [terrain]
    args['_terrain_families'] = [str(x) for x in terrain if str(x).strip()]
    return args

def start_search(payload_json):
    global _worker, _last_args, _next_start
    try:
        payload = json.loads(payload_json or '{}')
        filters = payload.get('filters', payload)
        portal = str(filters.get('portal', '')).strip().upper()
        if not portal:
            raise ValueError('Enter a portal address before starting a real search.')
        # HTML dropdown values are internal indices 0–255; names are labels only.
        galaxy = core.normalize_internal_galaxy_index(filters.get('galaxy', 0))
        batch = max(1, int(filters.get('batch', 64) or 64))
        limit = max(batch, int(filters.get('systemLimit', 6400) or 6400))
        target = max(1, int(filters.get('stopAfter', 1) or 1))
        until = bool(filters.get('until', True))
        args = _map_filters(filters, portal, galaxy, target)
        with _lock:
            _cancel.clear(); _pause.clear()
            _state.update({"running": True, "paused": False, "status": "Starting engine scan", "tested_systems": 0,
                "tested_planets": 0, "matches": [], "error": None, "system_limit": limit,
                "batch": batch, "until_found": until, "target": target, "request": payload,
                "galaxy_index": galaxy, "galaxy_name": core.galaxy_name_from_internal_index(galaxy)})
            _last_args = args
            _next_start = 0
        _worker = threading.Thread(target=_run_scan, args=(args,), daemon=True)
        _worker.start()
    except Exception as e:
        with _lock: _state.update({"running": False, "status": "Could not start search", "error": str(e)})

def _run_scan(args):
    global _next_start
    with _lock: start = _next_start
    try:
        while not _cancel.is_set():
            with _lock:
                limit = int(_state['system_limit']); batch = int(_state['batch'])
                until = bool(_state['until_found']); target = int(_state['target'])
                current_matches = len(_state['matches'])
            if start >= limit or (until and current_matches >= target): break
            count = min(batch, limit - start)
            call_args = dict(args)
            terrain_families = call_args.pop('_terrain_families', [])
            passes = terrain_families or [None]
            result = {'matches': [], 'tested_systems': 0, 'tested_planets': 0}
            # Multiple terrain selections are ORed by separate engine passes and deduplicated below.
            for terrain_family in passes:
                if _cancel.is_set(): break
                pass_args = dict(call_args)
                if terrain_family is not None:
                    pass_args['terrain_setting'] = terrain_family
                pass_result = core.find_planets(start_system=start, system_count=count, **pass_args)
                result['tested_systems'] = max(int(result.get('tested_systems', 0) or 0), int(pass_result.get('tested_systems', 0) or 0))
                result['tested_planets'] += int(pass_result.get('tested_planets', 0) or 0)
                result['matches'].extend(pass_result.get('matches', []) or [])
            matches = result.get('matches', []) or []
            with _lock:
                known = {json.dumps(x, sort_keys=True, default=str) for x in _state['matches']}
                for item in matches:
                    key = json.dumps(item, sort_keys=True, default=str)
                    if key not in known:
                        _state['matches'].append(item); known.add(key)
                _state['tested_systems'] = start + int(result.get('tested_systems', count) or count)
                _state['tested_planets'] += int(result.get('tested_planets', 0) or 0)
                _state['status'] = 'Found target' if len(_state['matches']) >= target else f"Scanned through system {start + count}"
            start += count
            with _lock: _next_start = start
            if not until and start >= limit: break
        with _lock:
            _state['running'] = False
            _state['status'] = 'Stopped' if _cancel.is_set() else ('Target reached' if len(_state['matches']) >= _state['target'] else 'Search limit reached')
    except Exception as e:
        with _lock: _state.update({"running": False, "status": "Engine error", "error": str(e), "traceback": traceback.format_exc()})

def set_paused(value):
    if value: _pause.set()
    else: _pause.clear()
    with _lock: _state['paused'] = bool(value); _state['status'] = 'Paused' if value else ('Searching' if _state['running'] else _state['status'])

def extend_search(systems):
    global _worker
    restart = False
    with _lock:
        _state['system_limit'] += max(1, int(systems or _state['batch']))
        _state['until_found'] = False
        _state['status'] = 'Search range extended'
        if not _state['running'] and _last_args is not None and _next_start < _state['system_limit']:
            _cancel.clear(); _pause.clear(); _state['running'] = True; restart = True
            args = _last_args
    if restart:
        _worker = threading.Thread(target=_run_scan, args=(args,), daemon=True)
        _worker.start()

def set_until_found(value):
    global _worker
    restart = False
    with _lock:
        _state['until_found'] = bool(value)
        if value and not _state['running'] and _last_args is not None and len(_state['matches']) < _state['target']:
            _cancel.clear(); _pause.clear(); _state['running'] = True; restart = True; args = _last_args
    if restart:
        _worker = threading.Thread(target=_run_scan, args=(args,), daemon=True)
        _worker.start()

def stop_search():
    _cancel.set(); _pause.clear()

def get_status_json():
    with _lock: return json.dumps(_state, default=str)
